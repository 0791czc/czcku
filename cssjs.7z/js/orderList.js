// 货物管理js
new Vue({
				el: ".container",
				data: {
					tabNum: 1,
					
					// 用户信息
					userInfo:{},
					// tab栏信息
					status:[
						{
							text:'待付款 ',
							code:0,
						},
						{
							text:'待发货 ',
							code:1,
						},
						{
							text:'待收货 ',
							code:2,
						},
						{
							text:'待评价 ',
							code:3,
						}
					],
										// 订单信息
					data:{}
				},
				methods: {

					tab(i) {
						this.tabNum = i;
						this.getOrderList(i);
					},
					// 去付款按钮					toPay(order_id){
						this.$http.get('/index/users/payAgain?id='+order_id).then(function(res) {
							if(res.body.code==400){
								alert(res.body.msg)
							}else{
								window.location.href = '/index/users/toPay';
							}
						}, function(err) {
							console.log('请求失败处理' + err);
						});
					},
					//点击提醒发货按钮
					tixfahuo(order_id){						this.$http.post('/index/users/noticeFahuo',{
							order_id: order_id,
						}).then(function(res) {
							alert(res.body.msg)
							window.location.reload();
						}, function(err) {
							console.log('请求失败处理' + err);
						});
					},
					//确认收货按钮
					confirmOrder(order_id){						this.$http.post('/index/users/confirmOrder',{
							order_id: order_id,
						}).then(function(res) {
							alert(res.body.msg)
							window.location.reload();
						}, function(err) {
							console.log('请求失败处理' + err);
						});
					},
					//去评价接口
					pinjiabutton(){
						// $(".pinjiaPang").css("display","flex")						
					},					
					//取消订单按钮					cancelOrder(order_id){
						this.$http.post('/index/users/cancelOrder',{
							order_id: order_id,
						}).then(function(res) {
							alert(res.body.msg)
							window.location.reload();
						}, function(err) {
							console.log('请求失败处理' + err);
						});
					},
					//
					quxiaouxiaoButton(){
						$(".quxiaodd").css("display","none")
					},
					// 获取用户信息
					getUserInfo(){
						this.$http.get('/index/Users/getUserInfo').then(function(res) {
							this.userInfo = res.body.data;
						}, function(err) {
							console.log('请求失败处理' + err);
						});
					},
					// 传订单状态获取订单列表
					getOrderList(status){
						this.$http.post('/index/users/getOrderList',{
							status: status,
						}).then(function(res) {
							this.data = res.body.data;
						}, function(err) {
							console.log('请求失败处理' + err);
						});
					},				},
				mounted(){					
					this.getOrderList(0);
					this.getUserInfo();
				}
			})