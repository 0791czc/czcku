var vm = new Vue ({
    el:'#productlist',
    data:{
		// 数据
		data:{},
		// 导航数据
		jddaohang: [],
		// 显示的商品数据列表
        list:[],
		// 分类列表
        aside:[],
		// 头部tab栏
		tabNum:0,
		// 左侧tab栏
		leftTabNum:-1,
    },
	methods:{
		// 获取页面部分数据
		getData(){
			let id = this.$refs.companyId.value;
			let shopcate = this.$refs.cateId.value;
			this.$http.get('/index/index/getShop?id='+id+'&shopcate='+shopcate).then(function(res) {
				this.data = res.body.data;
				this.aside = this.data.catelist;
				this.jddaohang = res.body.data.nav;
				for (let i in this.jddaohang) {
					if(this.jddaohang[i].id == shopcate){
						this.tabNum = i;
					}
				}
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取商品数据
		getGoodsData(shopcate){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getGoodsList?shopid='+id+'&shopcate='+shopcate).then(function(res) {
				this.list = res.body.data.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 左侧tab栏切换
		leftTab(i){
			this.leftTabNum = i;
			this.getGoodsData(this.aside[i].id)
		},
		// 关注店铺
		collectShop(id){
			this.$http.post('/index/Users/usersCollect', {
				shops_id: id,
			}).then(function(res) {
				alert(res.body.msg)
				if(res.body.code==200){
					if(this.data.is_follow == 1){
						this.data.is_follow = 0;
					}else{
						this.data.is_follow = 1;
					}
				}
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//点击立即购买
		lijigm(goods_id) {
			this.$http.post('/index/Users/checkOrder', {
				goods_id:goods_id,
				goods_num: 1,
			}).then(function(res) {
				window.location.href = '/index/users/checkOrder';
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//点击加入购物车
		addcar(goods_id) {
			this.$http.post('/index/Users/addToWarehouse', {
				goods_id:goods_id,
				goodsNum: 1,
			}).then(function(res) {
				window.location.href = '/index/users/mywarehouse.html';
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},
	},
	mounted(){
		let shopcate = this.$refs.cateId.value;
		this.getData();
		this.getGoodsData(shopcate);
	},
})