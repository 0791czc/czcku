// 品牌海澜之家js
var vm = new Vue({
	el:"#hlzj",
	data:{
		conNum:1,
	},
	methods:{
		titTab(i){
			this.conNum = i;
		},
		backTop(){
			 document.documentElement.scrollTop = document.body.scrollTop = 0;
		}
	},
	mounted(){
	},
})








