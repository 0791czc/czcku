// 挂载vue
var vm = new Vue({
	// topArticle ：顶条文章
	// swiperData : 轮播数据
	// swiper2Data :轮播下面数据  
	// navData : 导航数据 
	// goodsCateData 商品分类数据
	// noticeArticle : 公告数据
	// brandDataSmall : 品牌分数据
	// zhuantiData : 专题释义数据
	// maiguang : 卖光为止数据
	// kucun ： 库存处理数据
	//tejia : 今日特价
	//hdtj ： 活动特价
	//smpleData : 样品出售
	el: "#shopIndex",
	data: {
		num1: '-1',
		num2: '-1',
		num3: '-1',
		brandNum: '-1',
		brandBottom:'',
		topArticle:[],
		brandDataSmall: [],
		navData: [],
		goodsCateData:[],
		noticeArticle:[],
		swiperData: [],
		swiper2Data: [],
		zhuantiData: [],
		userInfo:{},//用户信息
		maiguang: [],
		kucun: [],
		tejia: [],
		hdtj:[],
		YPleftData:[
        ],
        YPcenterData:[
        ],
        YPrightData:[
        ]
		,
		serveData: [
			{
          img: "/static/index/img/yiliao.png",
          title: "医疗",
          titlep: "寻找附近的药店，医院或者上门体检以及送药"
        },
        {
          img: "/static/index/img/bangyun.png",
          title: "电工",
          titlep: "寻找附近的电工及时维护好家庭电路"
        },
        {
          img: "/static/index/img/diangong.png",
          title: "同城搬运",
          titlep: "最快的速度找到最近的搬运服务"
        }
		],
		bgColor:{
			 background: ""
		},
		merchantData: [],//本周推荐数据
		swiperOption1:{
			slidesPerView: 1,
			spaceBetween: 30,
			loop: true,
			observer: true,
			observeParents: true,
			lazy: {
			  loadPrevNext: true,
			},
			autoplay: {
				delay: 3000,
				disableOnInteraction: false,
			},
			on:{
				mouseover(){
					console.log(this)
					console.log(1)
					this.autoplay.stop();
				},
				mouseleave(){
					console.log(this)
					console.log(1)
					this.autoplay.start();
				},
				click:function(e){
					const i = this.realIndex;
					vm.jumpNewhtml(vm.swiperData[i].url)
					// vm.viewDetails(id);
				},
				slideChange:function (e) {
					const i = this.realIndex;
					vm.bgColor.background = vm.swiperData[i].bgcolor;
				}
			},
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			}
		},
		swiperOption2:{
			slidesPerView: 2,
			spaceBetween: 0,
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption3:{
			slidesPerView: 1,
			spaceBetween: 0,
			direction:'vertical',
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption4:{
			slidesPerView: 5,
			observer: true,
			observeParents: true,
			loop: true,
			on:{
				click:function(e){
					const i = this.realIndex;
					vm.jumpNewhtml(vm.maiguang[i].url)
					// vm.viewDetails(id);
				}
			},
			autoplay: {
				delay: 5000,
				disableOnInteraction: false,
			},
		},
	},
	methods: {
		// 获取用户信息
		getuserInfo(){
			this.$http.get('/index/Users/getUserInfo').then(function(res) {
				if(res.body.code == 200){
					this.userInfo = res.body.data;
				}
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取顶条文章
		gettopArticle(){
			this.$http.get('/index/article/getList?id=1').then(function(res) {
				this.topArticle = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取公告文章
		getnoticeArticle(){
			this.$http.get('/index/article/getList?id=2').then(function(res) {
				this.noticeArticle = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取导航数据
		getNav(){
			this.$http.get('/index/type/getList?pid=1').then(function(res) {
				this.navData = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取商品分类
		getGoodsCate(){
			this.$http.get('/index/index/getIndexGoodsCate').then(function(res) {
				this.goodsCateData = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//根据分类id获取品牌
		getCateBrand(catId){
			this.$http.get('/index/index/getCateBrand?cid='+catId+"&&num="+17).then(function(res) {
				this.brandDataSmall = [];
				this.brandDataSmall = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取大轮播广告图片
		getswiperData(){
			this.$http.get('/index/banner/getBanners?id=10').then(function(res) {
				this.swiperData = res.body.data;
				this.bgColor.background = this.swiperData[0].bgcolor;
				this.swiperData.map(item => {
					let image = new URLSearchParams
					image.append("path", item.image)
					image.append("interlace", true)
					item.image = `/img_conv.php?${image.toString()}`
					return item
				})
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取小轮播广告图片
		getswiper2Data(){
			this.$http.get('/index/banner/getBanners?id=11').then(function(res) {
				this.swiper2Data = res.body.data;
				this.swiper2Data.map(item => {
					let image = new URLSearchParams
					image.append("path", item.image)
					image.append("interlace", true)
					item.image = `/img_conv.php?${image.toString()}`
					return item
				})
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取专题释义
		getzhuantiData(){
			this.$http.get('/index/index/getSpecial').then(function(res) {
				console.log(res.body.data)
				this.zhuantiData = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取卖光为止栏目数据
		getMaiGuang(){
			this.$http.get('/index/index/getSpecialGoods?special=3&&num=10').then(function(res) {
				this.maiguang = res.body.data;
				this.maiguang.map(item => {
					let image = new URLSearchParams
					image.append("path", item.logo)
					image.append("width", 194)
					image.append("interlace", true)
					item.logo = `/img_conv.php?${image.toString()}`
					return item
				})
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取库存处理数据
		getKuCun(){
			this.$http.get('/index/index/getSpecialGoods?special=2&&num=4').then(function(res) {
				this.kucun = res.body.data;
				this.kucun.map(item => {
					let image = new URLSearchParams
					image.append("path", item.logo)
					image.append("width", 187)
					image.append("interlace", true)
					item.logo = `/img_conv.php?${image.toString()}`
					return item
				})
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取今日特价数据
		getTeJia(){
			this.$http.get('/index/index/getSpecialGoods?special=7&&num=6').then(function(res) {
				this.tejia = res.body.data;
				this.tejia.map(item => {
					let image = new URLSearchParams
					image.append("path", item.logo)
					image.append("width", 188)
					image.append("interlace", true)
					item.logo = `/img_conv.php?${image.toString()}`
					return item
				})
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取活动特价数据
		getHDTeJia(){
			this.$http.get('/index/index/getSpecialGoods?special=1&&num=6').then(function(res) {
				this.hdtj = res.body.data;
				this.hdtj.map(item => {
					let image = new URLSearchParams
					image.append("path", item.logo)
					image.append("width", 188)
					image.append("interlace", true)
					item.logo = `/img_conv.php?${image.toString()}`
					return item
				})
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取样品出售数据
		getYangPing(){
			this.$http.get('/index/index/getSpecialGoods?special=4').then(function(res) {
				let 样品数据 = res.body.data.map(item => {
					let image = new URLSearchParams
					image.append("path", item.logo)
					image.append("width", 90)
					image.append("height", 76)
					image.append("interlace", true)
					item.logo = `/img_conv.php?${image.toString()}`
					return item
				})
				this.YPleftData = 样品数据.splice(0,3);
				this.YPcenterData = 样品数据.splice(0,4);
				this.YPrightData = 样品数据.splice(0,4);
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取本周推荐数据
		getmerchantData(){
			this.$http.get('/index/index/getSpecialBrandsGoods?special=6').then(function(res) {
				this.merchantData = res.body.data;
				this.merchantData.map(brand => {
					brand.list.map(item => {
						let image = new URLSearchParams
						image.append("path", item.logo)
						image.append("width", 199)
						image.append("interlace", true)
						item.logo = `/img_conv.php?${image.toString()}`
						return item
					})
					return brand
				})
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		leave: function() {
			this.num1 = -1;
			this.num2 = -1;
			this.num3 = -1;
		},
		tab1over: function(index) {
			this.num1 = index;
			this.num2 = -1;
			this.num3 = -1;
		},
		tab2over: function(index) {
			this.num2 = index;
			this.num3 = -1;
			this.brandDataSmall = [];
		},
		tab2out(){
			this.num2 = -1;
		},
		tab3over: function(index, index1,catId,e) {
			this.num2 = index;
			this.brandNum = index;
			this.num3 = index1;
			this.getCateBrand(catId);
			// console.log(this.$refs.brandTop[i].getBoundingClientRect().top);
			if(e.clientY>400){
				this.brandBottom = 'brandBot';
			}else{
				this.brandBottom = "";
			}
		},
		tab3out (){
			this.num3 = -1;
		},
		brandOn(index){
			this.num2 = index;
		},
		brandOff(){
			this.num2 = -1;
			this.num3 = -1;
		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},
	},
	beforeCreate(){
		//判断是否支持vue
		if (!'defineProperty' in Object) {
		    alert('当前浏览器版本不支持，请升级版本或更换浏览器！');
		}
	},
	created(){
		this.gettopArticle();
		this.getNav();
		this.getnoticeArticle();
		this.getGoodsCate();
		this.getswiperData();
		this.getMaiGuang();
		let this_ = this;
		$(window).scroll(function(){
			let scrollTop = $(this).scrollTop();
			if(scrollTop >= 100){
				this_.getKuCun();
			}
			if(scrollTop >= 700){
				this_.getTeJia();
				this_.getHDTeJia();
			}
			if(scrollTop >= 1300){
				this_.getYangPing();
			}
			if(scrollTop >= 2200){
				this_.getmerchantData();
			}
			console.log(scrollTop)
		})
	},
	mounted() {
		// 调用获取数据的方法
		// this.getKuCun();
		// this.getTeJia();
		// this.getHDTeJia();
		// this.getYangPing();
		// this.getmerchantData();
	}
})
