var head = new Vue({
	el: "#head",
	data: {
		userBoxIson:false,//控制个人信息是否显示
		userInfo:{},//用户信息
		// 搜索框里的关键字
		keyword:'',
	},
	methods: {
		//控制登录后点击出现用户信息
		userBoxSwitch(){
			this.userBoxIson = !this.userBoxIson;
		},
		//退出登录
		exit(){
			this.$http.get('/index/Login/loginOut').then(function(res) {
				alert('退出登录成功');
				// 退出登录成功后重新加载页面
				location.reload();
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//我的购物仓跳转
		// toCar(){
		// 	window.location.href = '/indexs/index/car.html';
		// },
		// 搜索
		search(){
			window.location.href = '/index/index/searchgoods.html?keyword='+this.keyword;
		}
	},
	mounted() {
	},
})