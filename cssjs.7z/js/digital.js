 new Vue({
     el: '#digital',
     data: {
        //  手机配件导航数据
         nanzhuang: [],
        //  摄影摄像导航数据
         nvzhuang: [],
        //  数码配件导航数据
        neiyi: [],
        // banner头部导航数据
         headNav: [],
        //  全部商品导航数据
         cebian: [],
        // 智能设备导航数据
        peishi: [],
        // 影音娱乐导航数据
        tongzhuang: [],
         //  轮播图数据
         swiperData: [],
         swiperData2: [],
         swiperOption1: {
			slidesPerView: 1,
			spaceBetween: 30,
			loop: true,
			observer: true,
			observeParents: true,
			lazy: {
				loadPrevNext: true,
			},
			autoplay: {
				delay: 3000,
				disableOnInteraction: false,
			},
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			}
		},
		swiperOption2: {
			slidesPerView: 2,
			spaceBetween: 0,
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption3: {
			slidesPerView: 1,
			spaceBetween: 0,
			direction: 'vertical',
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption4: {
			slidesPerView: 5,
			observer: true,
			observeParents: true,
			loop: true,
			on: {
				click: function (e) {
					console.log(e.target.dataset.jumpurl)
					console.log(e.currentTarget)
					console.log(this.realIndex)
					// const id = this.realIndex;
					// vm.viewDetails(id);
				}
			},
			autoplay: {
				delay: 5000,
				disableOnInteraction: false,
			},
        },
        // 手机配件列表数据
        shoujipeijian:[],
        // 摄影摄像列表数据
        sheyingshexiang:[],
        // 数码配件列表数据
        shumapeijian:[],
        // 智能设备列表数据
        zhinengshebei:[],
        // 影音娱乐列表数据
        yingyinyule:[],
     },
     methods: {
		// 获取侧边栏
		getlist() {
			this.$http.get('/index/index/getIndexGoodsCate?cate=8').then(function (res) {
				if (res.body.code == 200) {
                    console.log(res.body.data)
					this.nanzhuang = res.body.data[0].children;
                    this.nvzhuang = res.body.data[1].children;
                    this.tongzhuang = res.body.data[4].children;
					this.neiyi = res.body.data[2].children;
					this.peishi = res.body.data[3].children;
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
		},
		getBanner() {
			this.$http.get('/index/banner/getBanners?id=16').then(function (res) {
				if (res.body.code == 200) {
					this.swiperData = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
		},
		getSmallBanner() {
			this.$http.get('/index/banner/getBanners?id=11').then(function (res) {
				if (res.body.code == 200) {
					this.swiperData2 = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getIndexGoodsCate').then(function (res) {
				if (res.body.code == 200) {
					console.log(res.body.data)
					this.cebian = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
        },
        getgoodslist(){
            this.$http.get('/index/type/getList?pid=1').then(function (res) {
				if (res.body.code == 200) {
					this.headNav = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=18&num=10').then(function (res) {
				if (res.body.code == 200) {
                    console.log(res.body.data.data)
					this.shoujipeijian= res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=19&num=10').then(function (res) {
				if (res.body.code == 200) {
					this.sheyingshexiang= res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=20&num=10').then(function (res) {
				if (res.body.code == 200) {
					this.shumapeijian= res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=21&num=10').then(function (res) {
				if (res.body.code == 200) {
					this.zhinengshebei= res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=22&num=10').then(function (res) {
				if (res.body.code == 200) {
					this.yingyinyule= res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
        }
	},
	created() {
		this.getlist()
		this.getBanner()
        this.getSmallBanner()
        this.getgoodslist()
	}

 })