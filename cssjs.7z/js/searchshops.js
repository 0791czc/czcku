//搜索结果js
var shoplist = new Vue({
	el:"#result",
	data:{		yeshu: 0,
		
		yema: 1,
		
		total:'',
		// 第几个排序
		rankNum:0,
		// 地址
		addressNum:0,
		shopListData:[
		],//商品列表数据
		//筛选数据		dataMsg:[],
		// 弹窗轮播图数据
		swiperData:[],		// 控制遮罩层显示
		shadeIson: false,
		swiperOptionTop: {
		  spaceBetween: 5,
		  loop: true,
		  loopedSlides: 9, 
		  navigation: {
			nextEl: '.swiper-button-next',
			prevEl: '.swiper-button-prev'
		  }
		},
		swiperOptionThumbs: {
		  spaceBetween: 5,
		  slidesPerView: 7,
		  touchRatio: 0.2,
		  loop: true,
		  loopedSlides: 9,
		  slideToClickedSlide: true,
		  watchSlidesVisibility: true,
		}
	},
	methods:{		// yemajian() {
		// 	if (this.yema <= 1) {
		// 		this.yema = 1;
		// 	} else {
		// 		this.yema -= 1;
		// 		this.getNewGoods();
		// 	}
		// },
		// yemajia() {
		// 	if (this.yema >= this.yeshu) {
		// 		this.yema = this.yeshu;
		// 	} else {
		// 		this.yema += 1;
		// 		this.getNewGoods();
		// 	}
		// },
		// 切换排序
		changeRank(i){
			this.rankNum = i;
		},
		// 切换地址
		changeAddress(i){
			this.addressNum = i;
		},
		// 获取商铺列表数据
		getShoplistData(){
			let keyword = this.$refs.keyword.value;
			this.$http.get('/index/index/getShopList?&keyword='+keyword).then(function(res) {
				this.shopListData = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 打开遮罩层看更多店铺图
		showMore(item){
			this.swiperData = item.shopsApply.shop_img.split(',');
			this.shadeIson = true;
		},
		// 关闭遮罩层
		closeShade(){
			this.shadeIson = false;
		},
		// 通过ip获取
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},
	},
	mounted(){		this.getShoplistData();
		this.$nextTick(() => {
			const swiperTop = this.$refs.swiperTop.swiper
			const swiperThumbs = this.$refs.swiperThumbs.swiper
			swiperTop.controller.control = swiperThumbs
			swiperThumbs.controller.control = swiperTop
		})
	}	
})