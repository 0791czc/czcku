var vm = new Vue({
    el:'#qydz',
    data:{
		// 数据
		data:{},
    	//头部导航
        jddaohang:[],
        //轮播
        swiperData:[
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
          ],
        //商品数据
        goodslist:[],
    },
	methods:{
		// 获取页面部分数据
		getData(){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getShop?id='+id).then(function(res) {
				this.data = res.body.data;
				this.jddaohang = res.body.data.nav;
				for (let i in this.jddaohang) {
					this.getGoodsData(this.jddaohang[i].id)
				}
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取商品数据
		getGoodsData(shopcate){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getGoodsList?shopid='+id+'&shopcate='+shopcate+'&num=4').then(function(res) {
				this.goodslist.push(res.body.data.data);
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 关注店铺
		collectShop(id){
			this.$http.post('/index/Users/usersCollect', {
				shops_id: id,
			}).then(function(res) {
				alert(res.body.msg)
				if(res.body.code==200){
					if(this.data.is_follow == 1){
						this.data.is_follow = 0;
					}else{
						this.data.is_follow = 1;
					}
				}
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},
	},
	mounted(){
		this.getData();
	},
})