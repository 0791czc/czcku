//今日特价js
// 挂载vue
var vm = new Vue({
	el: ".jrtj-con",
	data: {
		titTabNum: 0,		zhuanqu1: [],
		zhuanqu2: [],
		zhuanqu3: [],
		zhuanqu4: [],
		materialBrand:[],//家用电器品牌数据
		clothingBrand:[],//服装服饰品牌数据
		appliancesBrand:[],//家装建材品牌数据
		digitalBrand:[],//电子数码品牌数据
		moreWiring: [], //更多特价
		
		yeshu:1,
		yema:1,
	},
	methods: {
		titTab(i) {
			this.titTabNum = i;
			if(i==1){
				this.getClothingBrand();
			}
			if(i==2){
				this.getAppliancesBrand();
			}
			if(i==3){
				this.getDigitalBrand();
			}
		},
		yemajian(){
			if(this.yema <= 1){
				this.yema = 1;
			}else{
				this.yema -=1;
			}
		},
		yemajia(){
			if(this.yema >= this.yeshu){
				this.yema = this.yeshu;
			}else{
				this.yema += 1;
			}
		},		// 返回顶部
		backTop(){
			document.documentElement.scrollTop = 0;
			document.body.scrollTop = 0;
		},
		// 获取活动特价家用电器品牌
		getMaterialBrand(){
			this.$http.get('/index/index/getSpecialBrandsGoods?special=7&cate=1&brandsnum=4&goodsnum=3').then(function(res) {
				this.materialBrand = res.body.data;
				console.log(res);
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价服装服饰品牌
		getClothingBrand(){
			this.$http.get('/index/index/getSpecialBrandsGoods?special=7&cate=2&brandsnum=4&goodsnum=3').then(function(res) {
				this.clothingBrand = res.body.data;
				console.log(res);
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价家装建材品牌
		getAppliancesBrand(){
			this.$http.get('/index/index/getSpecialBrandsGoods?special=7&cate=595&brandsnum=4&goodsnum=3').then(function(res) {
				this.appliancesBrand = res.body.data;
				console.log(res);
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价电子数码品牌
		getDigitalBrand(){
			this.$http.get('/index/index/getSpecialBrandsGoods?special=7&cate=8&brandsnum=4&goodsnum=3').then(function(res) {
				this.digitalBrand = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价专区1
		getDigitalCate1(cate){
			this.$http.get('/index/index/getSpecialGoods?special=7&cate='+cate+'&num=6').then(function(res) {
				this.zhuanqu1 = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价专区2
		getDigitalCate2(cate){
			this.$http.get('/index/index/getSpecialGoods?special=7&cate='+cate+'&num=6').then(function(res) {
				this.zhuanqu2 = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价专区3
		getDigitalCate3(cate){
			this.$http.get('/index/index/getSpecialGoods?special=7&num=6&cate='+cate).then(function(res) {
				this.zhuanqu3 = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价专区4
		getDigitalCate4(cate){
			this.$http.get('/index/index/getSpecialGoods?special=7&cate='+cate+'&num=6').then(function(res) {
				this.zhuanqu4 = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},		//获取更多特价
		getMoreWiring(cate) {
			
			this.$http.get('/index/index/getSpecialGoods?special=7&&cate='+cate).then(function(res) {
				
				if (res.body.data.length > 12) {
				
					this.yeshu = Math.ceil(res.body.data.length / 12)
				
					for (var j = 0; j < this.yeshu; j++) {
				
						this.moreWiring.push(res.body.data.splice(0, 12));
				
					}
				
				} else {
				
					this.moreWiring.push(res.body.data);
				
				}
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//页面跳转函数
		jumpNewhtml(url) {
			window.location.href = url;
		},
	},
	mounted() {		this.getMaterialBrand();
		this.getDigitalCate1(702);
		this.getDigitalCate2(703);
		this.getDigitalCate3(704);
		this.getDigitalCate4(705);
		this.getMoreWiring(1);
	},
})
//得在数据更新之后渲染
Vue.nextTick(function () {
  vm.headerH2 = "今日特价";
})