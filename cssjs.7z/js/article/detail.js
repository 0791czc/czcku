//文章详情js
// 挂载vue
var vm = new Vue({
	el: ".newsCon",
	data: {
		articleList:[],
		headerH2:"",
	},
	methods: {
		// 获取文章列表
		getarticleList(){
			this.$http.get('/index/article/getList?id=2').then(function(res) {
				this.articleList = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
	},
	mounted() {
		this.getarticleList();
	},
})
//得在数据更新之后渲染
Vue.nextTick(function () {
  vm.headerH2 = "新闻页面";
})