//三级导航装饰建材
new Vue({
	el: ".jzjcBox",
	data: {
		// 瓷砖导航数据
		nanzhuang: [],
		// 卫浴导航数据
		nvzhuang: [],
		// 地板导航数据
		neiyi: [],
		// 木门导航数据
		peishi: [],
		// 墙面材料导航数据
		tongzhuang: [],
		// 灯具导航数据
		lamps: [],
		// 门窗导航数据
		doors: [],
		// 窗帘导航数据
		curtain: [],
		// 整体橱衣柜导航数据
		wardrobe: [],
		// 其他导航数据
		other: [],
		headNav: [],
		//品牌推荐数据
		pinPaiTuiJian: [],
		//瓷砖数据
		ciZhuang: [],
		//卫浴数据
		weiYu: [],
		// 地板数据
		diban:[],
		// 木门数据
		mumen:[],
		// 墙面材料数据
		qiangmiancailiao:[],
		//灯具数据
		dengJu: [],
		//门窗数据
		jiaShi: [],
		//窗帘数据
		wuJin: [],
		// 整体橱衣柜
		chuyigui:[],
		//其它数据左侧
		qiTa: [],
		//其它数据右侧
		qiTaR: [],
		// 全部商品导航
		cebian: [],
		// 轮播图数据
		swiperData: [],
		swiperData2: [],
		swiperOption1: {
			slidesPerView: 1,
			spaceBetween: 30,
			loop: true,
			observer: true,
			observeParents: true,
			lazy: {
				loadPrevNext: true,
			},
			autoplay: {
				delay: 3000,
				disableOnInteraction: false,
			},
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			}
		},
		swiperOption2: {
			slidesPerView: 2,
			spaceBetween: 0,
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption3: {
			slidesPerView: 1,
			spaceBetween: 0,
			direction: 'vertical',
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption4: {
			slidesPerView: 5,
			observer: true,
			observeParents: true,
			loop: true,
			on: {
				click: function (e) {
					console.log(e.target.dataset.jumpurl)
					console.log(e.currentTarget)
					console.log(this.realIndex)
					// const id = this.realIndex;
					// vm.viewDetails(id);
				}
			},
			autoplay: {
				delay: 5000,
				disableOnInteraction: false,
			},
        },

	},
	methods: {
		// 获取导航数据
		getlist() {
			this.$http.get('/index/index/getIndexGoodsCate?cate=595').then(function (res) {
				if (res.body.code == 200) {
					console.log(res.body.data)
					    this.nanzhuang = res.body.data[0].children;
						// 卫浴导航数据
						this.nvzhuang = res.body.data[1].children;
						// 地板导航数据
						this.neiyi = res.body.data[2].children;
						// 木门导航数据
						this.peishi = res.body.data[3].children;
						// 墙面材料导航数据
						this.tongzhuang = res.body.data[4].children;
						// 灯具导航数据
						this.lamps = res.body.data[5].children;
						// 门窗导航数据
						this.doors = res.body.data[6].children;
						// 窗帘导航数据
						this.curtain = res.body.data[7].children;
						// 整体橱衣柜导航数据
						this.wardrobe = res.body.data[8].children;
						// 其他导航数据
						this.other = res.body.data[9].children;
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/type/getList?pid=1').then(function (res) {
				if (res.body.code == 200) {
					this.headNav = res.body.data

				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getIndexGoodsCate').then(function (res) {
				if (res.body.code == 200) {
					this.cebian = res.body.data

				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/banner/getBanners?id=17').then(function (res) {
				if (res.body.code == 200) {
					this.swiperData = res.body.data

				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/banner/getBanners?id=11&num=4').then(function (res) {
				if (res.body.code == 200) {
					this.swiperData2 = res.body.data

				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
		},
        getgoodslist(){
            this.$http.get('/index/index/getCateBrand?cid=595&num=6').then(function (res) {
				if (res.body.code == 200) {
					this.pinPaiTuiJian = res.body.data
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=597&num=8').then(function (res) {
				if (res.body.code == 200) { 
					this.ciZhuang = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=602&num=8').then(function (res) {
				if (res.body.code == 200) {
					this.dengJu = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=598&num=8').then(function (res) {
				if (res.body.code == 200) {
					this.weiYu = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=603&num=8').then(function (res) {
				if (res.body.code == 200) {
					this.jiaShi = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=603&num=8').then(function (res) {
				if (res.body.code == 200) {
					this.wuJin = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=599&num=8').then(function (res) {
				if (res.body.code == 200) {
					this.diban = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=600&num=8').then(function (res) {
				if (res.body.code == 200) {
					this.mumen = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=601&num=8').then(function (res) {
				if (res.body.code == 200) {
					this.qiangmiancailiao = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=605&num=8').then(function (res) {
				if (res.body.code == 200) {
					this.chuyigui = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=606&num=8').then(function (res) {
				if (res.body.code == 200) {
					console.log(res.body.data) 
					this.qita = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
		}
	},
	created() {
		this.getlist()
		this.getgoodslist()
	}
})