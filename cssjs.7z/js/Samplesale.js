/**
 * @author Administrator
 */
//样品出售js
//调数据
var vm = new Vue({
	el: ".container",
	data: {
		headerH2:"",
		titTabNum: 0,
		electric: [],
		clothing: [],
		material: [],
		digital: []
/*		
		swiperOption4:{
		  spaceBetween: 10,
		  loop:true,
		  thumbs: {
		    swiper: {
		      el: '#thumbs4',
		      spaceBetween: 10,
		      slidesPerView: 4,
		      watchSlidesVisibility: true,
		    },
		  }
		},*/
	},
	methods: {
		titTab(i) {
			this.titTabNum = i;
		},
		getElectric() {
			this.$http.post('http://sert.zxits.cn/indexs/index/get_index_goods', {
				type: "maig",
				num: 8,
				catid: "334"
			}).then(function(res) {
				this.electric = res.body;
				//						console.log(res.body)
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		getClothing() {
			this.$http.post('http://sert.zxits.cn/indexs/index/get_index_goods', {
				type: "maig",
				num: 8,
				catid: "348"
			}).then(function(res) {
				this.clothing = res.body;
				//						console.log(this.clothing)
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		getMaterial() {
			this.$http.post('http://sert.zxits.cn/indexs/index/get_index_goods', {
				type: "maig",
				num: 8,
				catid: "55"
			}).then(function(res) {
				this.material = res.body;
				//						console.log(res.body)
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		getDigital() {
			this.$http.post('http://sert.zxits.cn/indexs/index/get_index_goods', {
				type: "maig",
				num: 8,
				catid: "51"
			}).then(function(res) {
				this.digital = res.body;
				//						console.log(res.body)
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		viewDetails(goodsId){
			window.location.href = 'http://sert.zxits.cn/indexs/shops/xqy?Id='+goodsId;
		},
	},
	mounted() {
		this.getElectric(),
		this.getClothing(),
		this.getMaterial(),
		this.getDigital()
	}
})
Vue.nextTick(function () {
  vm.headerH2 = "样品出售";
})