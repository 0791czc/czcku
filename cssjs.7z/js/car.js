// 挂载vue

var vm = new Vue({

	el: ".car-con",

	data: {

		address: [

			"江西南昌",

			"江西上饶余干",

			"地球村中国江西南昌"

		],

		checkedGoods: [], //存选取商品的ID格式为商铺id：[被选取商品id]

		checkedShop: [],

		jiesuan: [],

		allChecked: false,

		shopData: [
			],
		historyOrder:[],//购买历史数据

		heji: 0.00,

		buyChecked: false,

	},

	methods: {

		// 全选按钮

		checkAll() {

			if (this.allChecked == true) {

				for (var i in this.shopData) {

					this.shopData[i].checked = true;

					this.checkShop(this.shopData[i], i);

				}

			} else {

				for (var i in this.shopData) {

					this.shopData[i].checked = false;

					this.checkShop(this.shopData[i], i);

				}

			}

		},

		// 选择商铺

		checkShop(shopItem, shopIndex) {

			if (shopItem.checked == false) {

				var a = this.checkedShop.indexOf(shopItem.id);

				this.checkedShop.splice(a, 1);

				for (var i in shopItem.shopsInfo) {

					shopItem.shopsInfo[i].checked = false;

					var goodsIndex = this.checkedGoods[shopIndex].indexOf(shopItem.shopsInfo[i].goods.id);

					this.checkedGoods[shopIndex].splice(goodsIndex, 1);

					var jiesuanIndex = this.jiesuan.indexOf(shopItem.shopsInfo[i].id);

					this.jiesuan.splice(jiesuanIndex, 1);
					
					this.heji -= parseFloat(shopItem.shopsInfo[i].goods.new_price)*shopItem.shopsInfo[i].num.toFixed(2);
				}

			} else {

				if (this.checkedShop.indexOf(shopItem.id) == -1) {

					this.checkedShop.push(shopItem.id);

				}

				for (var i in shopItem.shopsInfo) {

					shopItem.shopsInfo[i].checked = true;

					if (this.checkedGoods[shopIndex] == undefined) {

						this.checkedGoods[shopIndex] = [];

						this.checkedGoods[shopIndex].push(shopItem.shopsInfo[i].goods.id);

					} else {

						if (this.checkedGoods[shopIndex].indexOf(shopItem.shopsInfo[i].goods.id) == -1) //判断是否存在于选中商品数组里，若没有则push，若有，则没有则什么都不干

							this.checkedGoods[shopIndex].push(shopItem.shopsInfo[i].goods.id);

					}

					if (this.jiesuan.indexOf(shopItem.shopsInfo[i].id) == -1) {

						this.jiesuan.push(shopItem.shopsInfo[i].id);
						this.heji += parseFloat(shopItem.shopsInfo[i].goods.new_price)*parseFloat(shopItem.shopsInfo[i].num).toFixed(2);

					}

				}

			}

			// 判断是否所有商铺都被选中，都被选中则全选变为选中状态

			if (this.shopData.length == this.checkedShop.length) {

				this.allChecked = true;

			} else {

				this.allChecked = false;

			}

		},
		// 减购物仓商品数量
		subNum(item) {
			if (item.num <= 1) {
				item.num = 1;
			} else {
				item.num = parseFloat(item.num) - 1;
				this.updateWarehouseNum(item.id,item.num)
				if(item.checked){
					this.heji -= parseFloat(item.goods.new_price); 
				}
			}
		},
		// 手动更改购物仓商品数量
		changeNum(item){
			let goodsNum = parseFloat(item.num);
			this.updateWarehouseNum(item.id,goodsNum)
		},
		// 加购物仓商品数量
		addNum(item) {
			if (item.num >= 999) {
				item.num = 999;
			} else {
				item.num = parseFloat(item.num) + 1;
				this.updateWarehouseNum(item.id,item.num);
				if(item.checked){
					this.heji += parseFloat(item.goods.new_price);
				}
			}
		},

		// 选择单个商品

		addxiaoji(item,shopId, goodsArr, shopIndex) {
			
			if (item.checked == false) {

				this.heji -= parseFloat(item.goods.new_price)*parseFloat(item.num).toFixed(2);

				var i = this.checkedGoods[shopIndex].indexOf(item.goods.id); //得到商品id在选中商品数组里的下标

				var j = this.jiesuan.indexOf(item.id); //得到购物车id在结算商品数组里的下标

				this.checkedGoods[shopIndex].splice(i, 1); //根据下标从选中商品数组里删除该商品id

				this.jiesuan.splice(j, 1); //根据下标从结算商品数组里删除该商品id

			} else {
				
				this.heji += parseFloat(item.goods.new_price)*parseFloat(item.num).toFixed(2);
				if (this.checkedGoods[shopIndex] == undefined) {

					this.checkedGoods[shopIndex] = [];

					this.checkedGoods[shopIndex].push(item.goods.id);

				} else {

					this.checkedGoods[shopIndex].push(item.goods.id);

				}

				this.jiesuan.push(item.id);

			}

			// 判断是否所有商品都被选中都选中则商铺变为选中状态

			if (goodsArr.length == this.checkedGoods[shopIndex].length) {

				this.shopData[shopIndex].checked = true;

				this.checkedShop.push(shopId);

			} else {

				this.shopData[shopIndex].checked = false;

				var a = this.checkedShop.indexOf(shopId);

				if (a != -1) {

					this.checkedShop.splice(a, 1);

				}

			}

			// 判断是否所有商铺都被选中，都被选中则全选变为选中状态

			if (this.shopData.length == this.checkedShop.length) {

				this.allChecked = true;

			} else {

				this.allChecked = false;

			}

		},
		// 获取购物车数据
		getCarData(){
			this.$http.post('/index/users/mywarehouse').then(function(res) {
				for (let i in res.body.data) {
					res.body.data[i].checked = false;
					for (let j in res.body.data[i].shopsInfo) {
						res.body.data[i].shopsInfo[j].checked = false;
					}
				}
				this.shopData = res.body.data;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 更新购物仓商品数量
		updateWarehouseNum(id,num){
			this.$http.post('/index/Users/updateWarehouseNum',{
				id:id,
				num:num,
			}).then(function(res) {
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 移入收藏夹
		moveToCollect(id,goodsId){
			this.$http.post('/index/Users/moveToCollect',{
				id:id,
				goods_id:goodsId,
			}).then(function(res) {
				alert(res.body.msg);
				window.location.reload();
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 移出购物仓
		delWarehouse(id){
			this.$http.post('/index/Users/delWarehouse',{
				id:id,
			}).then(function(res) {
				alert(res.body.msg);
				window.location.reload();
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 点击结算按钮
		toCheckOrder(){
			if(this.jiesuan.length > 0){
				this.$http.post('/index/Users/checkOrder',{
					cartIds:this.jiesuan,
				}).then(function(res) {
					window.location.href = '/index/users/checkOrder#2';
				}, function(err) {
					console.log('请求失败处理' + err);
				});
			}else{
				alert('请选择结算商品')
			}
		},
		// 获取购买历史
		// getHistoryOrder(){
		// 	this.$http.get('/index/users/getHistoryOrder').then(function(res) {
		// 		this.historyOrder = res.body.data;
		// 		console.log(res);
		// 	},function(err) {
		// 		console.log('请求失败处理' + err);
		// 	});
		// },
	},

	mounted() {
		this.getCarData();
	},

})
