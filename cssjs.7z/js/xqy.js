//详情页js

Vue.use(window.VueAwesomeSwiper)

var vm = new Vue({

	el: '#xqy',

	data: {
		goodsId:'',
		
		lunboNum: 0,

		tabNum: 0,
		
		//头部导航
		jddaohang:[],
		//三级联动

		topImgSrc:'',//缩略图上面图片地址

		isChange: false,

		isDown: false,

		Area: {

			province: "请选择",

			city: "请选择",

			region: "请选择",

		},
		
		adress: {

			province: [],

			city: [],

			region: []

		},

		data: {

			shop:{}

		},

		//三级联动结束

		//轮播

		swiperOptionTop: {

			spaceBetween: 10,

			loop: true,

//			loopedSlides: 5, //looped slides should be the same

			observer: true,

			observeParents: true

		},

		swiperOptionThumbs: {

			spaceBetween: 10,

			slidesPerView: 4,

			touchRatio: 0.2,

//			loop: true,

//			loopedSlides: 5, //looped slides should be the same

//			slideToClickedSlide: true,

//								observer: true,

//								observeParents: true

			//					navigation: {

			//						nextEl: '.swiper-button-next',

			//						prevEl: '.swiper-button-prev'

			//					}

		},

		//选择规格

		choiceSpec: [],
		
		// 规格
		spec:'',
		
		// 数量
		choiceNum:1,
		
		// 库存
		store:0,
		//商铺介绍

		shopjieshao: [{

				name: "商铺",

				title: "乐架电器旗舰店"

			},

			{

				name: "描述",

				title: "Haier"

			},

			{

				name: "联系",

				title: "联系客服"

			}

		],

		//锚点链接

		maodianNum: 0,

		//好评度关键字

		haopduright: [{

				title: "冰箱空间大",

				num: "789"

			},

			{

				title: "噪音小",

				num: "100"

			},

			{

				title: "外观好看",

				num: "99"

			},

			{

				title: "材质很好",

				num: "78"

			},

			{

				title: "节能省电",

				num: "99"

			},

			{

				title: "冰箱不错",

				num: "234"

			},

			{

				title: "整体感觉不错",

				num: "88"

			},

			{

				title: "功能很齐全",

				num: "89"

			}

		],

		//右侧关键字

		pjiagjianziNum: -1,

		//评论筛选

		plshxNum: 0,
		
		// 商品咨询
		goodsAsk:[],
		
		// 提问
		question:'',

		//评论内容

		plCont: [
		],
		
		//回复评论

		huifuNum: -1,

		yiruNum:0

	},

	methods: {
		clickTab(i) {

			this.tabNum = i;

		},
		// 获取页面店铺数据
		getNavData(){
			let id =  this.$refs.shopId.value;
			this.$http.get('/index/index/getShop?id='+id).then(function(res) {
				this.jddaohang = res.body.data.nav;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取商品详细数据
		getDetailData() {
			this.$http.get('/index/index/getGoods?id=' + this.goodsId).then(function(res) {
				this.data = res.body.data;
				let content = (new DOMParser()).parseFromString(this.data.content, "text/html")
				content.querySelectorAll("img").forEach(img => {
					let image = new URLSearchParams
					image.append("path", img.getAttribute("src"))
					image.append("interlace", true)
					img.setAttribute("src", `/img_conv.php?${image.toString()}`)
				})
				this.data.content = content.getElementsByTagName("body")[0].innerHTML
				this.data.goodslist.map(item => {
					if (item.logo !== null) {
						let image = new URLSearchParams
						image.append("path", item.logo)
						image.append("width", 147)
						image.append("height", 147)
						image.append("interlace", true)
						item.logo = `/img_conv.php?${image.toString()}`
						return item
					}
				})
				if(this.data.image.length>0){
					this.topImgSrc = this.data.image[0]; 	
				}
				if(this.data.spec_type == 2){
					if(this.data.spec_val.length>0){
						for (let i in this.data.spec_val) {
							let val = this.data.spec_val[i].val[0].id
							let obj = {
								id:val
							}
							this.choiceSpec.push(obj)
						}
						this.changePrice();
					}
				}
				this.shopjieshao[0].title = this.data.shop.shopname;
				this.shopjieshao[1].title = this.data.shop.description;
			}, function(err) {

				console.log(err);

			});

		},
		// 根据规格修改价格
		changePrice(){
			let key = '';
			for (let i in this.choiceSpec) {
				key = key + '_' +this.choiceSpec[i].id;
			}
			this.spec = key.substr(1)
			this.$http.get('/index/index/getGoodsSpecAttr?key=' + this.spec).then(function(res) {
				this.data.new_price = res.body.data.price;
				this.store = res.body.data.store;
			}, function(err) {
				console.log(err);
			});
		},
		// 获取评论内容
		getGoodsComments(){
			this.$http.get('/index/index/getGoodsComments?id=' + this.goodsId).then(function(res) {
				this.plCont = res.body.data.data;
			}, function(err) {
			
				console.log(err);
			
			});
		},
		// 获取商品咨询
		getGoodsAsk(){
			this.$http.get('/index/index/getGoodsAsk?id=' + this.goodsId).then(function(res) {
				this.goodsAsk = res.body.data.data;
			}, function(err) {
				console.log(err);
			});
		},
		// 获取用户地址
		getMyAdress() {

			this.$http.get('/index/users/getuseraddress').then(function(res) {

				this.myAdress = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		}, //三级联动结束



		//选择颜色

		choiceColorTab(i,id) {

			this.choiceSpec[i].id = id;
			
			this.changePrice();

		},

		//选择数量选择器

		jia() {

			if(this.choiceNum < 999) {

				this.choiceNum += 1;

			} else {

				this.choiceNum = 999;

			}



		},

		jian() {

			if(this.choiceNum > 1) {

				this.choiceNum -= 1;

			} else {

				this.choiceNum = 1;

			}

		},

		//锚点链接

		maodianTab(i) {

			this.maodianNum = i;

		},

		//右侧关键字

		pjiagjianziTab(i) {

			this.pjiagjianziNum = i;

		},

		//评论筛选

		plshxTab(i) {

			this.plshxNum = i;

		},
		
		//提问咨询
		setGoodsAsk(){
			this.$http.post('/index/users/goodsAsk',{
				content:this.question,
				goods_id:this.goodsId,
			}).then(function(res) {
				alert(res.body.msg);
				window.location.reload();
				console.log(res);
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		
		//回复评论

		huifuTab(i) {

			this.huifuNum = i;

			this.plCont[i].huifuON = !this.plCont[i].huifuON;

		},

		//赞

		zan(i) {

			this.plCont[i].zanON = !this.plCont[i].zanON;

			if(this.plCont[i].zanON == true) {

				this.plCont[i].zan += 1;

			} else {

				this.plCont[i].zan -= 1;

			}

		},

		//缩略图点击

		suonuetu(src,i) {

			this.topImgSrc = src;
			
			this.lunboNum = i;

		},
		// 关注店铺
		collectShop(id){
			this.$http.post('/index/Users/usersCollect', {
				shops_id: id,
			}).then(function(res) {
				alert(res.body.msg)
				if(res.body.code == 200){
					if(this.data.is_follow == 1){
						this.data.is_follow = 0;
					}else{
						this.data.is_follow = 1;
					}
				}
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 收藏商品
		collectGood(id){
			this.$http.post('/index/Users/usersCollect', {
				goods_id: id,
			}).then(function(res) {
				alert(res.body.msg)
				if(res.body.code==200){
					if(this.data.is_follow == 1){
						this.data.is_follow = 0;
					}else{
						this.data.is_follow = 1;
					}
				}
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},

		//点击立即购买

		lijigm(goods_id) {
			
			this.$http.post('/index/Users/checkOrder', {
				goods_id:goods_id,
				goods_num: this.choiceNum,
				spec_val:this.spec,
			}).then(function(res) {
				window.location.href = '/index/users/checkOrder';
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
			
		},

		//点击加入购物车

		addcar(goods_id) {
			
			this.$http.post('/index/Users/addToWarehouse', {
				goods_id:goods_id,
				goodsNum: this.choiceNum,
				spec_val:this.spec,
			}).then(function(res) {
			
				window.location.href = '/index/users/mywarehouse.html';
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});

			

		},

		//点击联系客服

		tokefu() {
			// 弹窗暂时不要
			// $(".zaixiankefu").css("display", "flex");
			window.open("https://wpa.qq.com/msgrd?v=3&uin=1776108119&site=qq&menu=yes","_blank"); 

		},

		//点击关闭界面

		closeKefu() {

			$(".zaixiankefu").css("display", "none");

		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},

		//放大镜

		fdaj(){

			var observer = new MutationObserver(function (mutations, observer) {

			  mutations.forEach(function(mutation) {

			    console.log(mutation);

			  });

			});

		}

	},
	beforeCreate() {
		
	},
	mounted () {
		this.goodsId = this.$refs.goodsId.value;//获取商品id
		// this.getAdress(); //三级联动
		
		this.getDetailData(); //获取详情页数据
		this.getGoodsComments(); //获取评价
		this.getGoodsAsk(); //获取商品咨询
		this.getNavData(); //获取导航数据
		this.$nextTick(() => {

			//					const swiperTop = this.$refs.swiperTop.swiper;

			//					const swiperThumbs = this.$refs.swiperThumbs.swiper;

			//					swiperTop.controller.control = swiperThumbs;

			//					swiperThumbs.controller.control = swiperTop;

		})

	}

})

//判断锚点链接距离顶部位置为零时，变为固定定位在顶部

// var zhxishop = document.getElementsByClassName("zhxishop")[0]; //左侧众兮商城内容

var maodianTitle = document.getElementsByClassName("maodianTitle")[0]; //右侧锚点链接文字

//		var mTop = zhxishop.offsetTop;//距离顶部距离



window.onscroll = function() {

	var topHeight = $(".choiceCangshu").height() + $(".yourAdd").height() + $(".header").height();

	var sTop = document.documentElement.scrollTop || document.body.scrollTop || window.pageYOffset; //滚动条距离顶部距离

	//			console.log(topHeight,sTop)

	if(sTop > topHeight) {

// 		$(".zhxishop").css("position", "fixed");
// 
// 		$(".zhxishop").css("top", "0");
// 
		$(".maodianTitle").css("position", "fixed");

		$(".maodianTitle").css("top", "0");

		$(".guigecanshu").css("padding-top", "60px")

	} else {

		// $(".zhxishop").css("position", "relative");

		$(".maodianTitle").css("position", "relative");

	}

}

//商品移入放大镜效果

function getByClass(oParent, sClass) {

	var aEle = oParent.getElementsByTagName('*');

	var aTmp = [];

	var i = 0;

	for (i = 0; i < aEle.length; i++) {

		if (aEle[i].className == sClass) {

			aTmp.push(aEle[i]);

		}

	}

	return aTmp;

}

window.onload = function() {

	var oDiv = document.getElementById('div1');

	var oMark = getByClass(oDiv, 'mark')[0];

	var oFloat = getByClass(oDiv, 'float_layer')[0];

	var oBig = getByClass(oDiv, 'big_pic')[0];

	var oSmall = getByClass(oDiv, 'small_pic')[0];

	var oImg = oBig.getElementsByTagName('img')[0];

	oMark.onmouseover = function() {

		oFloat.style.display = 'block';

		oBig.style.display = 'block';

	};

	oMark.onmouseout = function() {

		oFloat.style.display = 'none';

		oBig.style.display = 'none';

	};

	oMark.onmousemove = function(ev) {

		var oEvent = ev || event;

		var l = oEvent.clientX - oDiv.offsetLeft - oSmall.offsetLeft - oFloat.offsetWidth / 2;

		var t = oEvent.clientY - oDiv.offsetTop - oSmall.offsetTop - oFloat.offsetHeight / 2;

		if (l < -5) {

			l = -5;

		} else if (l > oMark.offsetWidth - oFloat.offsetWidth + 5) {

			l = oMark.offsetWidth - oFloat.offsetWidth + 5;

		}

		if (t < -5) {

			t = -5;

		} else if (t > oMark.offsetHeight - oFloat.offsetHeight + 5) {

			t = oMark.offsetHeight - oFloat.offsetHeight + 5;

		}

		oFloat.style.left = l + 'px';

		oFloat.style.top = t + 'px';

		var tempX = l / (oMark.offsetWidth - oFloat.offsetWidth);

		var tempY = t / (oMark.offsetHeight - oFloat.offsetHeight);

		oImg.style.left = -tempX * (oImg.offsetWidth - oBig.offsetWidth) + 'px';

		oImg.style.top = -tempY * (oImg.offsetHeight - oBig.offsetHeight) + 'px';

	}

};