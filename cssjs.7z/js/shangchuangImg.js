			//身份证图片
			//正面
			function scIDZ(file) {
				alert(file)  
				var scIDZ = document.getElementById('scIDZ');
				if(file.files && file.files[0]) {
					var reader = new FileReader();
					reader.onload = function(evt) {
						scIDZ.innerHTML = '<img src="' + evt.target.result + '" class="img-kuai"/><input type="file" onchange="scIDZ(this)" class="shcinput" /><p>身份证人像面</p></div>';

					}
					reader.readAsDataURL(file.files[0]);
				} else {
					scIDZ.innerHTML = '<div class="img"style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
				}
				
			}
			//反面
			function scIDF(file) {
				var scIDF = document.getElementById('scIDF');
				if(file.files && file.files[0]) {
					var reader = new FileReader();
					reader.onload = function(evt) {
						scIDF.innerHTML = '<img src="' + evt.target.result + '" class="img-kuai"/><input type="file" onchange="scIDF(this)" class="shcinput" /><p>身份证国徽面</p></div>';
					}
					reader.readAsDataURL(file.files[0]);
				} else {
					scIDF.innerHTML = '<div class="img"style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
				}
			}
			
			//商铺信息图片
			//上传图片
			function preview(file) {
				var prevDiv = document.getElementById('preview');
				if(file.files && file.files[0]) {
					var reader = new FileReader();
					reader.onload = function(evt) {
						prevDiv.innerHTML = '<img src="' + evt.target.result + '" class="img-kuai"/><input type="file" onchange="preview(this)" class="shcinput" /></div>';
					}
					reader.readAsDataURL(file.files[0]);
				} else {
					prevDiv.innerHTML = '<div class="img"style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
				}
			}
			//上传图片
			function preview2(file) {
				var prevDiv = document.getElementById('preview2');
				if(file.files && file.files[0]) {
					var reader = new FileReader();
					reader.onload = function(evt) {
						prevDiv.innerHTML = '<img src="' + evt.target.result + '" class="img-kuai"/><input type="file" onchange="preview2(this)" class="shcinput" /></div>';
					}
					reader.readAsDataURL(file.files[0]);
				} else {
					prevDiv.innerHTML = '<div class="img"style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
				}
			}
			//上传图片
			function preview3(file) {
				var prevDiv = document.getElementById('preview3');
				if(file.files && file.files[0]) {
					var reader = new FileReader();
					reader.onload = function(evt) {
						prevDiv.innerHTML = '<img src="' + evt.target.result + '" class="img-kuai"/><input type="file" onchange="preview3(this)" class="shcinput" /></div>';
					}
					reader.readAsDataURL(file.files[0]);
				} else {
					prevDiv.innerHTML = '<div class="img"style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
				}
			}
			//上传图片
			function preview4(file) {
				var prevDiv = document.getElementById('preview4');
				if(file.files && file.files[0]) {
					var reader = new FileReader();
					reader.onload = function(evt) {
						prevDiv.innerHTML = '<img src="' + evt.target.result + '" class="img-kuai"/><input type="file" onchange="preview3(this)" class="shcinput" /></div>';
					}
					reader.readAsDataURL(file.files[0]);
				} else {
					prevDiv.innerHTML = '<div class="img"style="filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=scale,src=\'' + file.value + '\'"></div>';
				}
			}