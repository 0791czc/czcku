var dianjidenglu = document.getElementsByClassName("dianjidenglu")[0];
var huiyuanNameReg = /^[\u4e00-\u9fa5a-zA-Z][0-9a-zA-Z_\u4e00-\u9fa5]{2,17}/; //会员名正则
var phonereg = /^1[3456789]\d{9}$/; //手机号码正则
var passreg = /[0-9a-zA-Z_]{6,16}/; //密码正则
console.log(dianjidenglu);
dianjidenglu.onclick = function() {
	if($(".username").val() == "" || $(".pasword").val() == ""){
		alert("用户名或密码错误")
	}
	$.post("/indexs/users/checkLogin.html", {
			loginName: $(".username").val(),
			loginPwd: $(".pasword").val(),
			rememberPwd: $(".checkboxx").val(),
		},
		function(status) {
			if(status.status == 1) {
				window.location.href = "http://dev.zqssqss.cn/indexs/";
			}else if(status.status == -1 ){
				console.log(status.msg )
				if(status.msg =="用户不存在"){
					$(".tishiusername").html(status.msg);
					$(".tishiusername").css("color","red")
				}else if(status.msg == "密码错误"){
					$(".tishipass").html(status.msg);
					$(".tishipass").css("color","red")
				}
				
			}
		});
}