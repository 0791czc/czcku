//服务对接js
// 挂载vue
var vm = new Vue({
	el:".fuwu-con",
	data:{
		headerH2:"",
		titTabNum:1,
		rightTabNum:0,
	},
	methods:{
		titTab(i){
			this.titTabNum = i;
		},
		rightTab(i){
			this.rightTabNum = i;
		}
	},
	mounted(){
	},
})
Vue.nextTick(function () {
  vm.headerH2 = "服务对接";
})