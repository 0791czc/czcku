//活动特价js

var hd = new Vue({

	el: ".hdtj-on",

	data: {

		titTabNum: 0,

		endTime: '2019-8-27',

		day: 0,
		h: 0,
		m: 0,
		s: 0,
		
		zhuanqu1: [],
		zhuanqu2: [],
		zhuanqu3: [],
		zhuanqu4: [],

		yeshu: 1,

		yema: 1,
		
		materialBrand:[],//家用电器品牌数据
		clothingBrand:[],//服装服饰品牌数据
		appliancesBrand:[],//家装建材品牌数据
		digitalBrand:[],//电子数码品牌数据
		
		moreWiring: [], //更多特价

	},

	methods: {

		titTab: function(i) {

			this.titTabNum = i;
			if(i==0){
				this.moreWiring= []
				this.getClothingBrand();
				this.getDigitalCate1(702);
				this.getDigitalCate2(703);
				this.getDigitalCate3(704);
				this.getDigitalCate4(705);
				this.getMoreWiring(1);
			}
			if(i==1){
				this.moreWiring= []
				this.getClothingBrand();
				this.getDigitalCate1(23);
				this.getDigitalCate2(24);
				this.getDigitalCate3(25);
				this.getDigitalCate4(26);
				this.getMoreWiring(2);
			}
			if(i==2){
				this.moreWiring= []
				this.getAppliancesBrand();
				this.getDigitalCate1(597);
				this.getDigitalCate2(598);
				this.getDigitalCate3(599);
				this.getDigitalCate4(600);
				this.getMoreWiring(595);
			}
			if(i==3){
				this.moreWiring= []
				this.getDigitalBrand();
				this.getDigitalCate1(18);
				this.getDigitalCate2(19);
				this.getDigitalCate3(20);
				this.getDigitalCate4(21);
				this.getMoreWiring(8);
			}
		},
		// 封装好的倒计时函数
		countdown() {

			const end = Date.parse(new Date(this.endTime));

			const now = Date.parse(new Date());

			const msec = end - now;

			let day = parseInt(msec / 1000 / 60 / 60 / 24);

			let hr = parseInt(msec / 1000 / 60 / 60 % 24);

			let min = parseInt(msec / 1000 / 60 % 60);

			let sec = parseInt(msec / 1000 % 60);

			this.day = day;

			this.h = hr > 9 ? hr : parseInt('0' + hr);

			this.m = min > 9 ? min : parseInt('0' + min);

			this.s = sec > 9 ? sec : parseInt('0' + sec);

		},
		// 获取活动特价家用电器品牌
		getMaterialBrand(){
			this.$http.get('/index/index/getSpecialBrandsGoods?special=1&cate=1&brandsnum=4&goodsnum=3').then(function(res) {
				this.materialBrand = res.body.data;
				console.log(res);
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价服装服饰品牌
		getClothingBrand(){
			this.$http.get('/index/index/getSpecialBrandsGoods?special=1&cate=2&brandsnum=4&goodsnum=3').then(function(res) {
				this.clothingBrand = res.body.data;
				console.log(res);
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价家装建材品牌
		getAppliancesBrand(){
			this.$http.get('/index/index/getSpecialBrandsGoods?special=1&cate=595&brandsnum=4&goodsnum=3').then(function(res) {
				this.appliancesBrand = res.body.data;
				console.log(res);
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价电子数码品牌
		getDigitalBrand(){
			this.$http.get('/index/index/getSpecialBrandsGoods?special=1&cate=8&brandsnum=4&goodsnum=3').then(function(res) {
				this.digitalBrand = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价专区1
		getDigitalCate1(cate){
			this.$http.get('/index/index/getSpecialGoods?special=1&cate='+cate+'&num=8').then(function(res) {
				this.zhuanqu1 = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价专区2
		getDigitalCate2(cate){
			this.$http.get('/index/index/getSpecialGoods?special=1&cate='+cate+'&num=8').then(function(res) {
				this.zhuanqu2 = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价专区3
		getDigitalCate3(cate){
			this.$http.get('/index/index/getSpecialGoods?special=1&num=8&cate='+cate).then(function(res) {
				this.zhuanqu3 = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取活动特价专区4
		getDigitalCate4(cate){
			this.$http.get('/index/index/getSpecialGoods?special=1&cate='+cate+'&num=8').then(function(res) {
				this.zhuanqu4 = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		yemajian() {

			if (this.yema <= 1) {

				this.yema = 1;

			} else {

				this.yema -= 1;

			}

		},

		yemajia() {

			if (this.yema >= this.yeshu) {

				this.yema = this.yeshu;

			} else {

				this.yema += 1;

			}

		},
		//获取更多特价
		getMoreWiring(cate) {
			
			this.$http.get('/index/index/getSpecialGoods?special=1&&cate='+cate).then(function(res) {
				console.log(res.body.data)
				
				if (res.body.data.length > 12) {
				
					this.yeshu = Math.ceil(res.body.data.length / 12)
				
					for (var j = 0; j < this.yeshu; j++) {
				
						this.moreWiring.push(res.body.data.splice(0, 12));
				
					}
				
				} else {
				
					this.moreWiring.push(res.body.data);
				
				}
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},

		//页面跳转函数
		jumpNewhtml(url) {
			window.location.href = url;
		},

	},

	mounted() {

		this.getMaterialBrand();
		this.getDigitalCate1(702);
		this.getDigitalCate2(703);
		this.getDigitalCate3(704);
		this.getDigitalCate4(705);
		this.getMoreWiring(1);

		this._interval = setInterval(() => {

			this.countdown();

		}, 1000)

	},

	destroyed() {

		clearInterval(this._interval)

	},

})
