var vm = new Vue({
    el: '#appliances',
    data: {
		// 大牌家具
		majorsuitCon:[],
		// 热销家具分类
		hotsellingdhNav:[],
		// 热销家具分类切换
		activeNum:0,
		  // 热销家具
		  hotsellingdhCon:[],
        // 客厅导航数据
        nanzhuang:[],
        // 卧室导航数据
        nvzhuang:[],
        // 书房导航数据
        neiyi:[],
        // 休闲导航数据
        peishi:[],
        // 儿童导航数据
        tongzhuang:[],
        // banner图上方导航
        headNav:[],
        // 轮播数据
        swiperData:[],
        swiperData2:[],
        swiperOption1: {
			slidesPerView: 1,
			spaceBetween: 30,
			loop: true,
			observer: true,
			observeParents: true,
			lazy: {
				loadPrevNext: true,
			},
			autoplay: {
				delay: 3000,
				disableOnInteraction: false,
			},
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			}
		},
		swiperOption2: {
			slidesPerView: 2,
			spaceBetween: 0,
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption3: {
			slidesPerView: 1,
			spaceBetween: 0,
			direction: 'vertical',
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption4: {
			slidesPerView: 5,
			observer: true,
			observeParents: true,
			loop: true,
			on: {
				click: function (e) {
					console.log(e.target.dataset.jumpurl)
					console.log(e.currentTarget)
					console.log(this.realIndex)
					// const id = this.realIndex;
					// vm.viewDetails(id);
				}
			},
			autoplay: {
				delay: 5000,
				disableOnInteraction: false,
			},
        },
        // 全部商品导航
        cebian:[],

    },
    methods: {
		// 获取导航数据
		getlist() {
			this.$http.get('/index/index/getIndexGoodsCate?cate=596').then(function (res) {
				if (res.body.code == 200) {
					console.log(res.body.data)
					this.nanzhuang = res.body.data[0].children;
					this.nvzhuang = res.body.data[1].children;
					this.neiyi = res.body.data[2].children;
                    this.peishi = res.body.data[3].children;
                    this.tongzhuang = res.body.data[4].children;
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/type/getList?pid=1').then(function (res) {
				if (res.body.code == 200) {
					this.headNav = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getIndexGoodsCate').then(function (res) {
				if (res.body.code == 200) {
					this.cebian = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/banner/getBanners?id=14').then(function (res) {
				if (res.body.code == 200) {
					this.swiperData = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/banner/getBanners?id=11').then(function (res) {
				if (res.body.code == 200) {
					this.swiperData2 = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
        },
        // 获取大牌家具数据
		getMajorsuitCon(){
			this.$http.get('/index/index/getCateBrand?cid=596').then(function (res) {
					this.majorsuitCon = res.body.data.data;
			            console.log(res);
				}, function (err) {
					console.log('请求失败处理' + err);
			    });
		},
		// 获取热销家具分类
        getHotsellingdhNav(){
			this.$http.get('/index/index/getGoodsCate?cate=596').then(function (res) {
				this.hotsellingdhNav = res.body.data;
			}, function (err) {
				console.log('请求失败处理' + err);
            });
        },
		// 热销家具分类切换
		tab(index){
			this.activeNum=index;
			this.getHotsellingdhCon(this.hotsellingdhNav[index].id)
		},
		// 获取热销家具商品
		getHotsellingdhCon(id){
			this.$http.get('/index/index/getGoodsList?cate='+id).then(function (res) {
				this.hotsellingdhCon = res.body.data.data;
			}, function (err) {
				console.log('请求失败处理' + err);
			});
		},
    },
    created () {
        this.getlist()
    },
	mounted(){
		this.getHotsellingdhNav()
		this.getHotsellingdhCon(673)
		this.getMajorsuitCon()
	},
})