// 企业家装js
new Vue({
    el:'#qyjz',
    data:{
		// 页面部分数据
		data:{},
        jddaohang:[],
        swiperData:[
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
          ],
		  // 畅销推荐
		  boomGoods:[],
		  // 经典商品
		  sutraGoods:[],
    },
	methods:{
		// 获取页面部分数据
		getData(){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getShop?id='+id).then(function(res) {
				this.data = res.body.data;
				this.jddaohang = res.body.data.nav;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取商品数据
		getGoodsData(){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getGoodsList?shopid='+id+'&page=1&num=10').then(function(res) {
				this.boomGoods = res.body.data.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取第二页商品数据
		getRmneirong(){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getGoodsList?shopid='+id+'&page=2&num=10').then(function(res) {
				this.sutraGoods = res.body.data.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},
	},
	mounted() {
		this.getData();
		this.getGoodsData();
		this.getRmneirong();
	}
})