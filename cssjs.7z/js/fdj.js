//放大镜
		//鼠标移入事件，让放大镜和放大区显示！
		pic_wrapover(index) {
			$(".float_box").eq(index).css("display", "block");
			$(".show").eq(index).css("display", "block");
		},
		//鼠标不断移动时触发，实时更新放大镜得到的图片
		pic_wrapmove(index,event) {
			var e = event || window.event;
			this.floatMove($(".float_box").eq(index), $(".pic_wrap").eq(index), e);
			this.showPic();
		},
		//鼠标移出后，放大镜和放大区隐藏
		pic_wrapout(index) {
			this.yiruNum=index;
			$(".float_box").eq(index).css("display", "none");
			$(".show").eq(index).css("display", "none");
		},
		//由于offset方法包括边框，在使用的时候很容易出现问题，所以用style来实时获取attr！
		getStyle(obj,attr) {
			console.log(obj[this.yiruNum]);
			console.log(attr);
			if(window.currentStyle) {
				return parseInt(obj[this.yiruNum].currentStyle[attr]);
				console.log(parseInt(obj[this.yiruNum].currentStyle[attr]));
			} else {
				return parseInt(getComputedStyle(obj[this.yiruNum],null)[attr]);
			}
		},
		//运动框架，控制放大镜在原图中的位置！
		floatMove(argu1, argu2, event){
			var e = event || window.event;
			var minLeft = this.getStyle(argu1, "width");
			var maxLeft = this.getStyle(argu2, "width") - minLeft / 2;
			var minHeight = this.getStyle(argu1, "height");
			var maxHeight = this.getStyle(argu2, "height") - minHeight / 2;
			console.log(maxLeft);
			console.log(maxLeft - minLeft / 2);
			if(e.clientX < minLeft / 2) {
				float_box[this.yiruNum].style.left = "0px"; //防止放大镜超出左边框
			} else if(e.clientX > maxLeft) {
				float_box[this.yiruNum].style.left = this.getStyle(argu2, "width") - this.getStyle(argu1, "width") + "px"; //防止放大镜超出右边框
			} else {
				float_box[this.yiruNum].style.left = event.clientX - minLeft / 2 + "px"; //放大镜完全在图片内时正常移动
			}
			if(e.clientY < minHeight / 2) {
				float_box[this.yiruNum].style.top = "0px"; //防止放大镜超出上边框
			} else if(e.clientY > maxHeight) {
				float_box[this.yiruNum].style.top = this.getStyle(argu2, "height") - this.getStyle(argu1, "height") + "px"; //防止放大镜超出下边框
			} else {
				float_box[this.yiruNum].style.top = event.clientY - minLeft / 2 + "px";
			}
		},
		//用来显示放大镜得到的图片，利用坐标计算！实时更新可视区域
		showPic() {
			var iCurLeft = this.getStyle(float_box[this.yiruNum], "left");
			var iCurTop = this.getStyle(float_box[this.yiruNum], "top");
			var a = this.getStyle(pic_wrap[this.yiruNum], "width") - this.getStyle(float_box[this.yiruNum], "width");
			var b = this.getStyle(big_img[this.yiruNum], "width") - this.getStyle(show, "width");
			var moveWidth = -(iCurLeft / a) * b;
			big_img[this.yiruNum].style.left = moveWidth + "px";
			var c = this.getStyle(pic_wrap[this.yiruNum], "height") - this.getStyle(float_box[this.yiruNum], "height");
			var d = this.getStyle(big_img[this.yiruNum], "height") - this.getStyle(show[this.yiruNum], "height");
			var moveHigth = -(iCurTop / c) * d;
			big_img[this.yiruNum].style.top = moveHigth + "px";
		}