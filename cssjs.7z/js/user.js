//账号管理js
// 挂载vue
var vm = new Vue({
	el: "#user",
	data: {
		tabNum: '0',
		userNum: '0',
		userinfo: {
			userName: ""
		},
		showUserName: "",
		userSex: 0,
		brithday: '',
		interestTag: [],
		newHeadImg: 'http://i.gtimg.cn/club/item/face/img/2/15052_100.png',
		isChange: false,
		isDown: false,
		openIdNum: '0',
		myId: '0',
		offNum: '0',
		Area: {
			province: "请选择",
			city: "请选择",
			region: "请选择",
		},		// 收货人
		adduserName: '',		// 收货地区
		addarea: '',		// 收货详细地址
		adduserAdress: '',		// 收货人手机号
		adduserPhone: '',		// 地址邮编
		addPostalCode: '',
		isDefault: 0,
		userAdress: {},
		tuijianImg: [
			"http://i.gtimg.cn/club/item/face/img/2/15052_100.png",
			"http://i.gtimg.cn/club/item/face/img/8/16258_100.png",
			"http://i.gtimg.cn/club/item/face/img/6/16206_100.png",
			"http://i.gtimg.cn/club/item/face/img/7/16207_100.png",
			"http://i.gtimg.cn/club/item/face/img/9/16209_100.png"
		],
		myAdress: [],
		adress: {
			province: [],
			city: [],
			region: []
		},		// 是否设为默认地址
		moren: false,
			
	},
	methods: {
		tab(num) {
			this.tabNum = num;
			this.userNum = 0;
			this.myId = 0;
			this.openIdNum = -1;
		},
		user(num) {
			this.userNum = num;
		},
		openId() {
			this.openIdNum = 1;
		},
		ocTab(i) {
			this.myId = i;
		},
		agree() {
			this.offNum = 1;
		},
		back() {
			this.offNum = 0;
			this.openIdNum = -1;
		},
		changeUserName() {
			if(this.isChange) {
				this.isChange = false;
			} else {
				this.isChange = true;
			}
		},		// 
		getShowUserName(e) {
			this.showUserName = e.target.value;
		},		// 设置兴趣爱好
		love(i) {
			this.interestTag[i].ison = !this.interestTag[i].ison;
		},		// 设置生日
		getbrithday(e) {
			this.brithday = e.target.value;
			
		},		// 设置性别
		getsex(num) {
			this.userSex = num;
		},		// 点击调用上传图片input
		uploadImg() {
			this.$el.querySelector('#img-upload').click();
		},		// 上传头像
		handleFile(e) {			let $target = e.target || e.srcElement;
			let file = $target.files[0];
			let formData = new FormData();
			formData.append('file', file);
			let config = {
				headers: {
					'Content-Type': 'multipart/form-data'
				}
			}
			// 调用上传图片接口
			this.$http.post('/index/users/uploadPic',
				formData, config
			).then(function(res) {
				this.newHeadImg = res.body.data.route + res.body.data.name;
				alert("头像上传成功")
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},		// 使用推荐头像
		tuiJianImg(i) {
			this.newHeadImg = this.tuijianImg[i];
		},		// 修改用户信息
		setuserinfo() {
			this.$http.post('/index/Users/editUserInfo', {
				nickname: this.showUserName,
				sex: this.userSex,
				birthday: this.brithday,
				like_cate: this.interestTag
			}).then(function(res) {

				alert(res.body.msg)
				
				window.location.reload();
				

			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},		// 修改头像之后保存
		setheadImg() {
			this.$http.post('/index/Users/editUserInfo', {
			
				avatar: this.newHeadImg,
			
			
			}).then(function(res) {
				alert(res.body.msg)
				window.location.reload();
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
		},
		//获取用户信息
		getuserinfo() {
			this.$http.get('/index/Users/getUserInfo').then(function(res) {
				this.userinfo = res.body.data;
				
				this.showUserName = this.userinfo.nickname;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		UpDown() {
			this.isDown = !this.isDown;
		},		// 获取省
		getAdress() {
			this.$http.post('/index/region/getregion', {
				parent_id: '0',
				
				type:'province',
			}).then(function(res) {				
				this.adress.province = res.body;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},		// 获取市
		getCity(parentId, provinceName) {
			this.Area.city = "请选择";
			this.Area.region = "请选择";
			this.Area.province = provinceName;
			this.$http.post('/index/region/getregion', {
				parent_id: parentId,
				
				type:'city',
			}).then(function(res) {

				this.adress.city = res.body;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},		// 获取县
		getRegion(parentId, cityName) {
			this.Area.city = cityName;
			this.Area.region = "请选择";
			this.$http.post('/index/region/getregion', {
				parent_id: parentId,
				
				type:'country',
			}).then(function(res) {
				
				this.adress.region = res.body;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		setArea(regionName, regionId) {			this.Area.region = regionName;
			this.addarea = this.Area.province+this.Area.city+this.Area.region;
			
			this.isDown = false;		},
		//获取地址
		getMyAdress() {
			this.$http.get('/index/Users/getAddressList').then(function(res) {				console.log(res);
				
				this.myAdress = res.body.data;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},		// 获取收货人姓名
		getadduserName(e) {			this.adduserName = e.target.value;		},		// 获取地址
		getadduserAdress(e) {			this.adduserAdress = e.target.value;		},		// 获取收货人手机号
		getadduserPhone(e) {			this.adduserPhone = e.target.value;		},
		//设为默认
		SheweiMoren(adressid) {			this.$http.post('/index/users/setDefauleAddr', {				id: adressid,			}).then(function(res) {				this.getMyAdress();			}, function(err) {				console.log('请求失败处理' + err);			});
		},
		//保存地址		saveAdress() {
			if(this.moren) {
				this.isDefault = 1;
			} else {
				this.isDefault = 0;
			}
			this.$http.post('/index/users/editUsersAddr', {
				consignee: this.adduserName,
				region: this.addarea,
				address: this.adduserAdress,
				tel: this.adduserPhone,
				is_default: this.isDefault,
			}).then(function(res) {
				alert(res.body.msg)
				this.getMyAdress();
			}, function(err) {
				console.log('请求失败处理' + err);
			});
			this.getMyAdress();
		},
		//删除地址
		delAdress(adressid) {
			this.$http.post('/index/users/delUserAddr', {
				id: adressid,
			}).then(function(res) {
				this.getMyAdress();
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
	},
	mounted() {
		this.getuserinfo();
		this.getMyAdress();
		this.getAdress();
	}
})
Vue.nextTick(function () {
  vm.headerH2 = "账号管理";
})