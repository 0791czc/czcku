/**
 * @author Administrator
 */ //swiper配置
//库存处理js
//调数据
var vm = new Vue({
	el: ".container",
	data: {
		electric: [],
		clothingB: [],
		clothing: [],
		getMaterial1: [],
		getMaterial2: [],
		maijiusong1:[],
		maijiusong2:[],
		fuzhuangfushi1:[],
		fuzhuangfushi2:[],
		jiazhjiancia1:[],
		jiazhjiancia2:[],
		dianzishuma1:[],
		dianzishuma2:[],
		yeshu: 1,
		yema: 1,
	},
	methods: {
		//tab切换栏
		titTab(i) {
			this.titTabNum = i;
		},
		//加页码点击事件
		yemajian() {
			if(this.yema <= 1) {
				this.yema = 1;
			} else {
				this.yema -= 1;
			}
		},
		yemajia() {
			if(this.yema >= this.yeshu) {
				this.yema = this.yeshu;
			} else {
				this.yema += 1;
			}
		},
		// 获取任你选栏目数据
		getElectric() {
			this.$http.get('/index/index/getSpecialGoods?special=2').then(function(res) {
				
				if (res.body.data.length > 12) {
				
					this.yeshu = Math.ceil(res.body.data.length / 12)
				
					for (var j = 0; j < this.yeshu; j++) {
				
						this.electric.push(res.body.data.splice(0, 12));
				
					}
				
				} else {
				
					this.electric.push(res.body.data);
				
				}
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取组合购买品牌数据
		getClothing() {
			this.$http.get('/index/index/getSpecialBrandsGoods?special=2&brandsnum=2&goodsnum=3').then(function(res) {
				this.clothing = res.body.data[0];
				this.clothingB = res.body.data[1]
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取买就送家用电器数据
		maijiusong() {
			this.$http.get('/index/index/getSpecialGoods?special=2&cate=1&num=8').then(function(res) {
				this.maijiusong1.push(res.body.data.splice(0, 4));
				this.maijiusong2.push(res.body.data.splice(0, 4));
				console.log(this.maijiusong1)
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取服装服饰数据
		fuzhuangfushi() {
			this.$http.get('/index/index/getSpecialGoods?special=2&cate=2&num=8').then(function(res) {
				this.fuzhuangfushi1.push(res.body.data.splice(0, 4));
				this.fuzhuangfushi2.push(res.body.data.splice(0, 4));
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取家装建材数据
		jiazhjiancia() {
			this.$http.get('/index/index/getSpecialGoods?special=2&cate=595&num=8').then(function(res) {
				this.jiazhjiancia1.push(res.body.data.splice(0, 4));
				this.jiazhjiancia1.push(res.body.data.splice(0, 4));
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取电子数码数据
		dianzishuma() {
			this.$http.get('/index/index/getSpecialGoods?special=2&cate=595&num=8').then(function(res) {
				console.log(res)
				this.dianzishuma1.push(res.body.data.splice(0, 4));
				this.dianzishuma1.push(res.body.data.splice(0, 4));
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},
	},
	mounted() {
		this.getElectric();
		this.getClothing();
		this.maijiusong();
		this.fuzhuangfushi();
		this.jiazhjiancia();
		this.dianzishuma();
	}
})