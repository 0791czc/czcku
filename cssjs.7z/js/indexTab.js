// 一级导航
$('.bannerBot').mouseleave(function(){
	$('.tab1').removeClass('on');
	$('.tab1-con').removeClass('on')
	$('.tab2').removeClass('on');
})
$('.tab1').mouseover(function(){
	console.log("移入了！");
	$(this).addClass('on').siblings().removeClass('on');
	var num = $(this).index();
	$('tab1-con').eq(num).addClass('on').siblings().removeClass('on');
})
$('.tab1').click(function() {
	console.log("点击了！");
	$(this).addClass('on').siblings().removeClass('on');
	var num = $(this).index();
	$('tab1-con').eq(num).addClass('on').siblings().removeClass('on');
})
// 二级导航
$('.tab2').mouseover(function(){
	console.log("移入了2！");
	$(this).addClass('on').siblings().removeClass('on');
})
$('.tab2').mouseout(function(){
	$(this).removeClass('on');
})
// 三级导航
$('.tab3').mouseover(function(){
	console.log("移入了3！");
	$(this).addClass('on').siblings().removeClass('on');
	var num = $(this).parent().index();
	$('tab2').eq(num).addClass('on').siblings().removeClass('on');
})
$('.tab3').mouseout(function(){
	$(this).removeClass('on');
})