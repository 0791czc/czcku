// 提交订单js
var order = new Vue({
			el:".container",
			data:{
				isCar:false,
				addNum:0,
				myAddress:[],//收货地址
				
				checkedAddress:{}, //选择的收货地址
				// anotherServers:[],//增值服务
				//存接收到的数据
				data:{},
				adress: {
				
					province: [],
				
					city: [],
				
					region: []
				
				},
				leaveWords:'',//留言内容
				isAdd:false,
				isDown: false,//控制地址选择显示
				//地址
				Area: {
				
					province: "请选择",
				
					city: "请选择",
				
					region: "请选择",
				
				},
				// 收货人
				adduserName: '',
				// 收货地区
				addarea: '',
				// 收货详细地址
				adduserAdress: '',
				// 收货人手机号
				adduserPhone: '',
				// 地址邮编
				addPostalCode: '',
				// 是否设为默认地址
				moren: false,				// 实付款总价
				zongjia:0,
				// 购物车id集合
				cartIds:[],
			},
			methods:{
				addTab(i){
					this.addNum = i;
					
					this.checkedAddress = this.address[i];
				},
				returngwuc(){
					//返回购物仓
//					alert("返回购物仓")
					window.location.href = '/index/users/mywarehouse.html';
				},
				// 下拉选择地区
				UpDown() {
				
					this.isDown = !this.isDown;
				
				},
				// 获取省
				getAdress() {
				
					this.$http.post('/index/region/getregion', {
				
						parent_id: '0',
						
						type:'province',
				
					}).then(function(res) {
						
						this.adress.province = res.body;
				
					}, function(err) {
				
						console.log('请求失败处理' + err);
				
					});
				
				},
				// 获取市
				getCity(parentId, provinceName) {
				
					this.Area.city = "请选择";
				
					this.Area.region = "请选择";
				
					this.Area.province = provinceName;
				
					this.$http.post('/index/region/getregion', {
				
						parent_id: parentId,
						
						type:'city',
				
					}).then(function(res) {
				
						this.adress.city = res.body;
				
					}, function(err) {
				
						console.log('请求失败处理' + err);
				
					});
				
				},
				// 获取县
				getRegion(parentId, cityName) {
				
					this.Area.city = cityName;
				
					this.Area.region = "请选择";
				
					this.$http.post('/index/region/getregion', {
				
						parent_id: parentId,
						
						type:'country',
				
					}).then(function(res) {
						
						this.adress.region = res.body;
				
					}, function(err) {
				
						console.log('请求失败处理' + err);
				
					});
				
				},
				
				setArea(regionName, regionId) {
				
					this.Area.region = regionName;
				
					this.addarea = this.Area.province+this.Area.city+this.Area.region;
					
					this.isDown = false;
				},				// 获取收货人姓名
				getadduserName(e) {
					this.adduserName = e.target.value;
				},
				// 获取地址
				getadduserAdress(e) {
					this.adduserAdress = e.target.value;
				},
				// 获取收货人手机号
				getadduserPhone(e) {
					this.adduserPhone = e.target.value;
				},
				// 获取地址
				getMyAddress(){
					this.$http.get('/index/Users/getAddressList').then(function(res) {
						this.myAddress = res.body.data;
						this.checkedAddress = this.myAddress[0];
					}, function(err) {
						console.log('请求失败处理' + err);
					});
				},
				//设为默认
				SheweiMoren(adressid) {
					this.$http.post('/index/users/setDefauleAddr', {
						id: adressid,
					}).then(function(res) {
						alert(res.body.msg)
						this.getMyAddress();
					}, function(err) {
						console.log('请求失败处理' + err);
					});
				
				},
				// 打开新增和修改地址弹窗
				addAddress(){
					this.isAdd = true;
				},
				// 关闭新增和修改地址
				closeAddAddress(){
					this.isAdd = false;
				},
				//保存地址
				saveAdress() {
					if(this.moren) {
						this.isDefault = 1;
					} else {
						this.isDefault = 0;
					}
					this.$http.post('/index/users/editUsersAddr', {
						consignee: this.adduserName,
						region: this.addarea,
						address: this.adduserAdress,
						tel: this.adduserPhone,
						is_default: this.isDefault,
					}).then(function(res) {
						this.closeAddAddress();
						this.getMyAddress();
					}, function(err) {
						console.log('请求失败处理' + err);
					});
					this.getMyAddress();
				},
				
				//获取详情页发过来的数据
				getDetailData(){					this.$http.get('/index/users/getSubmitInfo').then(function(res) {
						this.data = res.body.data;
						if(this.data.total_price !=undefined){
							this.zongjia = this.data.total_price;
						}else{
							for (let i in this.data) {
								this.zongjia += this.data[i].total_price;
								for (let j in this.data[i].shopsInfo) {
									this.cartIds.push(this.data[i].shopsInfo[j].id)
								}
							}
						}
					}, function(err) {
						console.log('请求失败处理' + err);
					});
				},
				//提交订单
				tijiaodd(){
					if(this.myAddress.length <= 0 ){
						alert('请添加收货地址！')
					}					if(this.data.id !=undefined){
						let spec_val = '';
						if(this.data.spec_type == 2){
							spec_val = this.data.spec_val.key;
						}
						console.log(this.checkedAddress.id,this.checkedAddress)
						this.$http.post('/index/users/submitOrder',{
							users_address_id:this.checkedAddress.id,
							goods_id:this.data.id,
							num:this.data.num,
							remarks:this.leaveWords,
							spec_val:spec_val,
						}).then(function(res) {
							if(res.data.code==200){
								window.location.href = '/index/users/toPay';
							}else{
								alert(res.data.msg)
							}
						}, function(err) {
							console.log('请求失败处理' + err);
						});
					}else{
						this.$http.post('/index/users/submitOrder',{
							users_address_id:this.checkedAddress.id,
							cartIds:this.cartIds,
							remarks:this.leaveWords,
						}).then(function(res) {
							if(res.data.code==200){
								window.location.href = '/index/users/toPay';
							}else{
								alert(res.data.msg)
							}
						}, function(err) {
							console.log('请求失败处理' + err);
						});
					}
				}
			},
			mounted(){
				this.getMyAddress(); //获取用户收货地址
				this.getDetailData(); //获取用户收货地址
				this.getAdress();//获取地址
			}
		})
		//默认第一个选中
		$(".radio").eq(0).attr("checked","checked");
		//留言
		$(".liuyan").focus(function(){
			$(".liuyanBox").css("background-color","rgba(249,198,188,1)");
			$(".liuyanBox").css("border","1px solid rgba(226,96,72,1)");
			$(this).css("background-color","rgba(249,198,188,1)")
		});
		$(".liuyan").blur(function(){
			$(".liuyanBox").css("background-color","white");
			$(".liuyanBox").css("border","0");
			$(".liuyanBox").css("border-top","1px solid #A6A6A6");
			$(this).css("background-color","white")
		});