new Vue({
	el: '#navigationClassification',
	data: {
		//男装导航数据
		nanzhuang: [],
		// 女装导航数据
		nvzhuang: [],
		// 内衣导航数据
		neiyi: [],
		// 配饰导航数据
		peishi: [],
		// 童装导航数据
		tongzhuang: [],
		// banner图顶部导航数据
		headNav: [],
		//潮流男装上部分数据
		chaoLiuManClothTop: [],
		//潮流男装下部分数据
		chaoLiuManClothBot: [],
		//时尚女装上部分数据
		shiShangWomanClothTop: [],
		//时尚女装下部分数据
		shiShangWomanClothBot: [],
		//精致内衣上部分数据
		jingZhiNeiYiTop: [],
		//精致内衣下部分数据
		jingZhiNeiYiBot: [],
		//潮流配饰上部分数据
		chaoLiuPeiShiTop: [],
		//潮流配饰下部分数据
		chaoLiuPeiShiBot: [],
		//精美童装上部分数据
		jingMeiTongZhuangTop: [],
		//精美童装下部分数据
		jingMeiTongZhuangBot: [],
		swiperData: [],
		swiperData2: [],
		cebian: [],
		swiperOption1: {
			slidesPerView: 1,
			spaceBetween: 30,
			loop: true,
			observer: true,
			observeParents: true,
			lazy: {
				loadPrevNext: true,
			},
			autoplay: {
				delay: 3000,
				disableOnInteraction: false,
			},
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			}
		},
		swiperOption2: {
			slidesPerView: 2,
			spaceBetween: 0,
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption3: {
			slidesPerView: 1,
			spaceBetween: 0,
			direction: 'vertical',
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption4: {
			slidesPerView: 5,
			observer: true,
			observeParents: true,
			loop: true,
			on: {
				click: function (e) {
					console.log(e.target.dataset.jumpurl)
					console.log(e.currentTarget)
					console.log(this.realIndex)
					// const id = this.realIndex;
					// vm.viewDetails(id);
				}
			},
			autoplay: {
				delay: 5000,
				disableOnInteraction: false,
			},
		},
		

	},
	methods: {
		// 获取侧边栏导航数据
		getlist() {
			this.$http.get('/index/index/getIndexGoodsCate?cate=2').then(function (res) {
				if (res.body.code == 200) {
					this.nanzhuang = res.body.data[0].children;
					this.nvzhuang = res.body.data[1].children;
					this.tongzhuang = res.body.data[2].children;
					this.neiyi = res.body.data[5].children;
					this.peishi = res.body.data[4].children;
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
		},
		getBanner() {
			this.$http.get('/index/banner/getBanners?id=15').then(function (res) {
				if (res.body.code == 200) {
					this.swiperData = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
		},
		getSmallBanner() {
			this.$http.get('/index/banner/getBanners?id=11').then(function (res) {
				if (res.body.code == 200) {
					this.swiperData2 = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
		},
		getgoodslist(){
			// 内容数据
			this.$http.get('/index/index/getCateBrand?cid=23&num=3').then(function (res) {
				if (res.body.code == 200) {
					this.chaoLiuManClothTop = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=23&num=3').then(function (res) {
				if (res.body.code == 200) {
					this.chaoLiuManClothBot = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getCateBrand?cid=24&num=3').then(function (res) {
				if (res.body.code == 200) {
					this.shiShangWomanClothTop = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=24&num=3').then(function (res) {
				if (res.body.code == 200) {
					this.shiShangWomanClothBot = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getCateBrand?cid=25&num=3').then(function (res) {
				if (res.body.code == 200) {
					this.jingMeiTongZhuangTop = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=25&num=3').then(function (res) {
				if (res.body.code == 200) {
					this.jingMeiTongZhuangBot = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getCateBrand?cid=27&num=3').then(function (res) {
				if (res.body.code == 200) {
					console.log(res.body.data)
					this.chaoLiuPeiShiTop = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=27&num=3').then(function (res) {
				if (res.body.code == 200) {
					console.log(res.body.data.data)
					this.chaoLiuPeiShiBot = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getCateBrand?cid=115&num=3').then(function (res) {
				if (res.body.code == 200) {
					console.log(res.body.data)
					this.jingZhiNeiYiTop = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getGoodsList?cate=115&num=3').then(function (res) {
				if (res.body.code == 200) {
					console.log(res.body.data.data)
					this.jingZhiNeiYiBot = res.body.data.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/type/getList?pid=1').then(function (res) {
				if (res.body.code == 200) {
					console.log(res.body.data)
					this.headNav = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getIndexGoodsCate').then(function (res) {
				if (res.body.code == 200) {
					console.log(res.body.data)
					this.cebian = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
		}
	},
	created() {
		this.getlist()
		this.getBanner()
		this.getSmallBanner()
		this.getgoodslist()
	}
})