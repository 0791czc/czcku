//搜索结果js

var goodsList = new Vue({

	el: ".searchBox",

	data: {
		yeshu: 0,

		yema: 1,

		total: '',

		goodsListData: [], //商品列表数据

		//筛选数据

		dataMsg: [

			{

				name: "品牌：",

				list: []

			},

			{

				name: "价格：",

				list: [

					"25000以上", "5000-24999", "10000-14999", "8000-9999", "6000-7999", "4000-5999", "2000-3999", "0-1999"

				]

			}

		],
		// 全部商品导航
		cebian: [],
	},

	methods: {

		//鼠标移入

		tabOver() {

			$(".tabHover").css("display", "inline-block")

		},

		//鼠标移出

		tabOut() {

			$(".tabHover").css("display", "none")

		},

		yemajian() {

			if (this.yema <= 1) {

				this.yema = 1;

			} else {

				this.yema -= 1;

				this.getNewGoods();

			}

		},

		yemajia() {

			if (this.yema >= this.yeshu) {

				this.yema = this.yeshu;

			} else {

				this.yema += 1;

				this.getNewGoods();

			}

		},
		// 获取全部商品分类
		getCebian() {
			this.$http.get('/index/index/getIndexGoodsCate').then(function(res) {
				if (res.body.code == 200) {
					this.cebian = res.body.data
				}
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取品牌
		getBrand() {
			let cid = this.$refs.cid.value;
			this.$http.get('/index/index/getCateBrand?cid=' + cid + "&num=" + 10).then(function(res) {
				this.dataMsg[0].list = [];
				this.dataMsg[0].list = res.body.data;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取商品
		getGoodList() {
			let cid = this.$refs.cid.value;
			this.$http.get('/index/index/getGoodsList?cate=' + cid).then(function(res) {
				this.goodsListData = res.body.data.data;
				this.goodsListData.map(item => {
					let image = new URLSearchParams
					image.append("path", item.logo)
					image.append("width", 200)
					image.append("height", 200)
					image.append("interlace", true)
					item.logo = `/img_conv.php?${image.toString()}`
					return item
				})
				this.total = res.body.data.total;
				this.yema = res.body.data.current_page;
				this.yeshu = res.body.data.last_page;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 页码改变商品数据改变
		getNewGoods() {
			let cid = this.$refs.cid.value;
			if (this.yema >= 1 && this.yema <= this.yeshu) {
				let page = this.yema;
				this.$http.get('/index/index/getGoodsList?cate=' + cid + '&page=' + page).then(function(res) {
					this.goodsListData = res.body.data.data;
					this.goodsListData.map(item => {
						let image = new URLSearchParams
						image.append("path", item.logo)
						image.append("width", 200)
						image.append("height", 200)
						image.append("interlace", true)
						item.logo = `/img_conv.php?${image.toString()}`
						return item
					})
				}, function(err) {
					console.log('请求失败处理' + err);
				});
			} else {

			}
		},
		// 排序
		getOrder(order) {
			let cid = this.$refs.cid.value;
			this.$http.get('/index/index/getGoodsList?cate=' + cid + '&order=' + order).then(function(res) {
				this.goodsListData = res.body.data.data;
				this.yema = res.body.data.current_page;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
	},

	mounted() {

		this.getCebian();

		this.getBrand();

		this.getGoodList();

	}

})

