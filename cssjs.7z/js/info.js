//商户后台

var vm = new Vue({

	el: ".houtaiBox",

	data: {

		//首页

		msg: [{

				icoImg: "/static/index/img/houtai-ico1.png ",

				title: "商铺管理 ",

				isOn: false,

				list: ["商铺基本设置 ",

					"系统消息 ",

					"商铺公告"

				]

			},

			{

				icoImg: "/static/index/img/houtai-ico2.png ",

				title: "商品管理 ",

				isOn: false,

				list: [

					"商品分类 ",

					"新增商品 ",

					"出售的商品 ",

					"审核中的商品 ",

					"仓库中的商品 ",

					"库存预警 ",

					"违规商品 ",

					"数据导入",

					"评价管理",

					"商品咨询"

				]

			},

			{

				icoImg: "/static/index/img/houtai-ico3.png ",

				title: "交易管理 ",

				isOn: false,

				list: [



					"已收货订单 ",

					"待付款订单 ",

					"待发货订单 ",

					"已发货订单 ",

					"取消/拒收订单 ",

					"投诉订单 "

				]

			},

			{

				icoImg: "/static/index/img/houtai-ico4.png ",

				title: "配送管理 ",

				isOn: false,

				list: [



					"服务商设置 ",

					"运费模板 ",

					"物流跟踪信息 ",

					"地址库 ",

					"物流服务 ",

					"我要寄快递 "

				]

			},

// 			{
// 
// 				icoImg: "/static/index/img/houtai-ico5.png ",
// 
// 				title: "促销推广 ",
// 
// 				isOn: false,
// 
// 				list: [
// 
// 
// 
// 					"订单查询与追踪 ",
// 
// 					"预售订单查询 ",
// 
// 					"订单管理 ",
// 
// 					"退款退货 ",
// 
// 					"发货管理 ",
// 
// 					"售后管理 ",
// 
// 					"评价管理 "
// 
// 				]
// 
// 			},
// 
// 			{
// 
// 				icoImg: "/static/index/img/houtai-ico6.png ",
// 
// 				title: "售后服务 ",
// 
// 				isOn: false,
// 
// 				list: [
// 
// 
// 
// 					"店铺认证 ",
// 
// 					"退款管理 ",
// 
// 					"投诉管理 ",
// 
// 					"申诉中心 ",
// 
// 					"换货管理 ",
// 
// 					"售后维修 "
// 
// 				]
// 
// 			},
// 
// 			{
// 
// 				icoImg: "/static/index/img/houtai-ico7.png ",
// 
// 				title: "数据库 ",
// 
// 				isOn: false,
// 
// 				list: [
// 
// 
// 
// 					//					"订单查询与追踪 ",
// 
// 					//					"预售订单查询 ",
// 
// 					//					"订单管理 ",
// 
// 					//					"退款退货 ",
// 
// 					//					"发货管理 ",
// 
// 					//					"售后管理 ",
// 
// 					//
// 
// 					//					"评价管理 "
// 
// 				]
// 
// 			},

// 			{
// 
// 				icoImg: "/static/index/img/houtai-ico8.png ",
// 
// 				title: "结算中心 ",
// 
// 				isOn: false,
// 
// 				list: [
// 


					//					"订单查询与追踪 ",

					//					"预售订单查询 ",

					//					"订单管理 ",

					//					"退款退货 ",

					//					"发货管理 ",

					//					"售后管理 ",

					//					"评价管理 "
// 
// 				]
// 
// 			},
			{
				icoImg: "/static/index/img/houtai-ico8.png ",
				title: "导入店铺 ",
				isOn: false,
// 				list: [



					//					"订单查询与追踪 ",

					//					"预售订单查询 ",

					//					"订单管理 ",

					//					"退款退货 ",

					//					"发货管理 ",

					//					"售后管理 ",

					//					"评价管理 "
// 
// 				]
// 
			}

		],

		//首页左侧切换

		Findex: -1,

		//首页左侧小切换

		Sindex: -1,

		//tab切换

		tabNum: 0,

		//我的账号管理

		xiugaiNum: 0,
		
		// 系统消息
		systemNews:[],

		//商铺公告

		shopNotice: '',

		//商户资料信息

		shopInfo: {

		},
		
		// 上次登录ip
		last_login_ip:'',
		
		// 用户登录名
		userName:'',
		
		// 店铺名
		shopName:'',
		
		// 商铺品牌
		shopBrand:'',
		shopBrandId:'',
		
		// 店铺基本信息修改
		shop:{
			shopname:'',
			logo:'',
			description:'',
			province:'',
			city:'',
			country:'',
			town:'',
			goods_supply:'',
			summary:'',
			seo_key:'',
			seo_desc:'',
			shops_search_key:'',
			shops_street_img:'',
			top_img:'',
			mobile_top_img:'',
			photos:'',
		},
		// 上传后前端显示banner
		bannerImages:[],
		// 传给后端的banner
		bannerPhotos:[],
		// 店铺logo
		logo:'',
		
		//控制默认设置

		morenshezhi: 0,
		// 商铺分类全选
		allCheck:false,

		//商城分类 
		cateList:[],
		
		// 交易管理订单列表
		ShopsOrderList:[],
		
		//三级联动

		topImgSrc: '', //缩略图上面图片地址

		isChange: false,

		isDown: false,

		Area: {

			province: "请选择省",

			city: "请选择市",

			region: "请选择县区",

		},

		adress: {

			province: [],

			city: [],

			region: []

		},

		data: {},

		//三级联动结束
		//第二个三级联动

		topImgSrc2: '', //缩略图上面图片地址

		isChange2: false,

		isDown2: false,

		Area2: {

			province: "请选择",

			city: "请选择",

			region: "请选择",

		},

		adress2: {

			province: [],

			city: [],

			region: []

		},

		data2: {},

		//第二个三级联动结束
		//第三个三级联动

		topImgSrc3: '', //缩略图上面图片地址

		isChange3: false,

		isDown3: false,

		Area3: {

			province: "请选择",

			city: "请选择",

			region: "请选择",

		},

		adress3: {

			province: [],

			city: [],

			region: []

		},

		data3: {},

		//第三个三级联动结束
		//第四个三级联动

		topImgSrc4: '', //缩略图上面图片地址

		isChange4: false,

		isDown4: false,

		Area4: {

			province: "请选择",

			city: "请选择",

			region: "请选择",

		},

		adress4: {

			province: [],

			city: [],

			region: []

		},

		data4: {},

		//第四个三级联动结束

		//新增商品中的tab切换

		xinzenNum: 0,

		//运费模板

		yunfeimubNum: -1,

		//配送管理中的我要寄快递tab切换

		jijianNum: 0,

		//点击已寄件tab切换

		yijijianNum: 0,

		//投诉管理tab切换

		tousuguanliNum: 0,

		//投诉中心tab切换

		shengsuzhongxNum: 0,

		//结算中心tab切换

		jiesuanzhongxinNum: 0,

		// 商品分类
		goodsCateList:[],

		//商品列表
		goodsList:{
			current_page:1,
			data:[],
			last_page:0,
			total:0,
		},
		// 商品数据
		goods:{
			title:'',
			old_price:'',
			new_price:'',
			number_stock:'',
			status:1,
			isShipping:1,
			cate_id:'',
			shops_cate_id:'',
			content:'',
			img:'',
			images:'',
		},
		// 商品图册
		shopImages:[],
		
		// 传给后台的图册
		shopPhotos:'',
		
		// 第一个分类
		firstTitle:'',

		//商铺装修tab

		shopPageTitNum: 0,

		//商铺装修页面tab

		shopPageNum: 0
	},

	methods: {
		
		// 退出登录
		exit(){
			this.$http.get('/index/shops/loginOut').then(function(res) {
				window.location.href = res.body.data;
			
			}, function(err) {
			
				console.log(err);
			
			});
		},

		//tab切换

		tab(i) {

			this.tabNum = i;

			if (this.tabNum == 0) {

				this.Sindex = -1;
				this.Findex = -1;

			}

		},

		//默认设置切换

		morenshezhiTab(i) {

			this.morenshezhi = i;

		},

		//首页

		toList(i) {

			this.Findex = i;

			this.Sindex = 0;
			
			this.msg[i].ison = !this.msg[i].ison;

			if (this.msg[i].ison == true && i != 6 && i != 7) {

				$('.list').eq(i).css("display", "block");

				$(".jiantou").eq(i).css("display", "none");

				$(".jiantouxia").eq(i).css("display", "block");
			} else if (this.msg[i].ison == false) {

				$('.list').eq(i).css("display", "none");

				$(".jiantou").eq(i).css("display", "block");

				$(".jiantouxia").eq(i).css("display", "none");

			}
			if(i == 2){
				this.getShopsOrderList(3)
			}
		},

		listCont(i, j) {

			this.Sindex = i;

			this.Findex = j;

			if (this.Findex == 3 && this.Sindex == 5) {

				this.yijijianNum = 0;

			}
			if(j==2){
				switch (i){
					case 0:
						this.getShopsOrderList(3)
						break;
					case 1:
						this.getShopsOrderList(0)
						break;
					case 2:
						this.getShopsOrderList(1)
						break;
					case 3:
						this.getShopsOrderList(2)
						break;
					case 4:
						this.getShopsOrderList(15)
						break;
					default:
						break;
				}
			}

		},
		//获取商铺资料
		
		getShopInfo() {
		
			this.$http.get('/index/shops/getShopsInfo').then(function(res) {
				let shopData = res.body.data;
				this.shopInfo = shopData.apply_info;
				
				this.last_login_ip = shopData.last_login_ip;
				
				this.userName = shopData.login_name;
				
				this.shopNotice = shopData.notice;
				
				this.shopName = shopData.shopname;
				
				this.logo = shopData.logo;
				
				this.last_login_ip = shopData.last_login_ip;
				
				this.shop.shopname = shopData.shopname;
				this.shop.logo = shopData.logo;
				this.shop.description = shopData.description;
				this.shop.province = shopData.province;
				this.shop.city = shopData.city;
				this.shop.country = shopData.country;
				this.shop.town = shopData.town;
				this.shop.goods_supply = shopData.goods_supply;
				this.shop.summary = shopData.summary;
				this.shop.seo_key = shopData.seo_key;
				this.shop.seo_desc = shopData.seo_desc;
				this.shop.shops_search_key = shopData.shops_search_key;
				this.shop.shops_street_img = shopData.shops_street_img;
				this.shop.top_img = shopData.top_img;
				this.shop.mobile_top_img = shopData.mobile_top_img;
				this.shop.photos = shopData.photos;
				
			}, function(err) {
		
				console.log(err);
		
			});
		
		},
		
		// 获取商铺品牌及商铺品牌ID
		getShopBrand(){
			this.$http.get('/index/shops/getShopsBrand').then(function(res) {
				
				this.shopBrand = res.body.data[0].title;
				this.shopBrandId = res.body.data[0].id;
				
			}, function(err) {
			
				console.log(err);
			
			});
		},
		
		//修改商铺公告
		
		saveNotice() {
		
			this.$http.post('/index/shops/setShopsNotice', {
		
				notice: this.shopNotice
		
			}).then(function(res) {
		
				alert('修改公告成功')
		
			}, function(err) {
		
				console.log('请求失败处理' + err);
		
			});
		
		},
		
		// 获取系统信息
		getSystemNews(){
			this.$http.get('/index/shops/getShopsSystemInfoList').then(function(res) {
				
				this.systemNews = res.body.data;
				
			}, function(err) {
			
				console.log(err);
			
			});
		},
		// 删除系统信息
		delNews(id){
			this.$http.post('/index/shops/delShopsSystemInfo', {
			
				id: id
			
			}).then(function(res) {
				
				this.getSystemNews();
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
		},
		// 店铺logo上传点击
		uploadLogo() {
			this.$el.querySelector('#logoInp').click()
		},
		// 店铺logo上传并显示
		logoInpChange(e) {
			let $target = e.target || e.srcElement;
			let file = $target.files[0];
			let formData = new FormData();
			formData.append('file',file);
			let config = {
				headers:{
					 'Content-Type': 'multipart/form-data'
				}
			}
			// 调用上传图片接口
			this.$http.post('/index/shops_apply/uploadPic', 
				formData,config
			).then(function(res) {
				this.shop.logo = res.body.data.route + res.body.data.name;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 上传(首页)商铺街背景图片
		uploadBg() {
			this.$el.querySelector('#bgInp').click()
		},
		// 商铺街背景图片上传并显示
		bgInpChange(e) {
			let $target = e.target || e.srcElement;
			let file = $target.files[0];
			let formData = new FormData();
			formData.append('file',file);
			let config = {
				headers:{
					 'Content-Type': 'multipart/form-data'
				}
			}
			// 调用上传图片接口
			this.$http.post('/index/shops_apply/uploadPic', 
				formData,config
			).then(function(res) {
				this.shop.shops_street_img = res.body.data.route + res.body.data.name;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 上传顶部广告图片
		uploadTopAd() {
			this.$el.querySelector('#topAdInp').click()
		},
		// 顶部广告图片上传并显示
		topAdInpChange(e) {
			let $target = e.target || e.srcElement;
			let file = $target.files[0];
			let formData = new FormData();
			formData.append('file',file);
			let config = {
				headers:{
					 'Content-Type': 'multipart/form-data'
				}
			}
			// 调用上传图片接口
			this.$http.post('/index/shops_apply/uploadPic', 
				formData,config
			).then(function(res) {
				this.shop.top_img = res.body.data.route + res.body.data.name;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 上传移动端顶部广告图片
		uploadAppTopAd() {
			this.$el.querySelector('#appTopAdInp').click()
		},
		// 移动端顶部广告图片上传并显示
		appTopAdInpChange(e) {
			let $target = e.target || e.srcElement;
			let file = $target.files[0];
			let formData = new FormData();
			formData.append('file',file);
			let config = {
				headers:{
					 'Content-Type': 'multipart/form-data'
				}
			}
			// 调用上传图片接口
			this.$http.post('/index/shops_apply/uploadPic', 
				formData,config
			).then(function(res) {
				this.shop.mobile_top_img = res.body.data.route+res.body.data.name;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 添加banner图
		addBanner(e){
		    e.preventDefault();
			this.$el.querySelector('#bannerPicInp').click()
		    return false;
		},
		// banner图input改变事件
		bannerInpChange(e) {
		    var files = e.target.files || e.dataTransfer.files;
		    if (!files.length)return; 
		    this.createBanner(files);
			this.bannerPhotos = files;
		},
		createBanner(file) {
		    if(typeof FileReader==='undefined'){
		        alert('您的浏览器不支持图片上传，请升级您的浏览器');
		        return false;
		    }
		    let image = new Image();         
		    let vm = this;
		    let leng=file.length;
		    for(let i=0;i<leng;i++){
		        let reader = new FileReader();
		        reader.readAsDataURL(file[i]); 
		        reader.onload =function(e){
					vm.bannerImages.push(e.target.result);
		        };                 
		    }                        
		},
		// 点击上传banner图
		async uploadbanner(){
			let formdata = new FormData()
			for (let bannerPhoto of this.bannerPhotos) {
				formdata.append("photos[]", bannerPhoto)
			}
			this.$http.post('/index/shops/uploadfiles',formdata, {
				headers:{
					 'Content-Type': 'multipart/form-data'
				}
			}).then(function(res) {
				alert(res.body.msg)
				this.shop.photos = res.body.data.join();
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
			
		},
		// 保存商户资料修改
		setShopsInfo(){
			this.$http.post('/index/shops/setShopsInfo', {
				shopname:this.shop.shopname,
				description:this.shop.description,
				logo:this.shop.logo,
				province:this.shop.province,
				city:this.shop.city,
				country:this.shop.country,
				town:this.shop.town,
				goods_supply:this.shop.goods_supply,
				summary:this.shop.summary,
				seo_key:this.shop.seo_key,
				seo_desc:this.shop.seo_desc,
				shops_search_key:this.shop.shops_search_key,
				shops_street_img:this.shop.shops_street_img,
				top_img:this.shop.top_img,
				mobile_top_img:this.shop.mobile_top_img,
				photos:this.shop.photos,
			}).then(function(res) {
				alert(res.body.msg)
				this.Sindex = -1;
				this.Findex = -1;
				this.getShopInfo();
				// location.reload();
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 清零商户资料修改
		resetShopInfo(){
			
		},
		// input改变事件
		 onFileChange(e) {
		    var files = e.target.files || e.dataTransfer.files;
		    if (!files.length)return; 
		    this.createImage(files);
			this.shopPhotos = files;
		},
		createImage(file) {
		    if(typeof FileReader==='undefined'){
		        alert('您的浏览器不支持图片上传，请升级您的浏览器');
		        return false;
		    }
		    let image = new Image();         
		    let vm = this;
		    let leng=file.length;
		    for(let i=0;i<leng;i++){
		        let reader = new FileReader();
		        reader.readAsDataURL(file[i]); 
		        reader.onload =function(e){
					vm.shopImages.push(e.target.result);
		        };                 
		    }                        
		},
		// 商品相册添加图片点击事件
		addGoodsPic(e){
		    e.preventDefault();
			this.$el.querySelector('#goodsPicInp').click()
		    return false;
		},
		// 上传点击事件
		async uploadGoodsImages(){
			let formdata = new FormData()
			for (let shopPhoto of this.shopPhotos) {
				formdata.append("photos[]", shopPhoto)
			}
			// let response = await fetch("/index/shops/uploadfiles", {
			// 	method: "POST",
			// 	body: formdata
			// })
			// let message = await response.json()
			// console.log(message)
			
			this.$http.post('/index/shops/uploadfiles',formdata, {
			
				headers:{
					 'Content-Type': 'multipart/form-data'
				}
			
			}).then(function(res) {
				
				console.log(res);
				alert(res.body.msg)
				this.goods.images = res.body.data.join();
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
			
		},
		// 移除所有图片点击事件
		removeGoodsImages(){
			this.shopImages = [];
		},
		// 传状态100 查全部， 0待付款 ，1待发货，2待收货，3待评价，4已完成 15 已取消获取交易订单
		getShopsOrderList(status){
			this.$http.post('/index/shops/getShopsOrderList', {
			
				status: status
			
			}).then(function(res) {
				
				this.ShopsOrderList = res.body.data;
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
		},
		
		//我的账号管理tab

		xiugaiTab(i) {

			this.xiugaiNum = i

		},

		
		//修改商铺资料

		//三级联动

		UpDown() {

			this.isDown = !this.isDown;

		},
		// 获取省
		getAdress() {

			this.$http.post('/index/region/getregion', {

				parent_id: '0',
				
				type: 'province'

			}).then(function(res) {

				this.adress.province = res.body;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},
		// 获取市
		getCity(parentId, provinceName) {

			this.Area.city = "请选择";

			this.Area.region = "请选择";

			this.Area.province = provinceName;

			this.$http.post('/index/region/getregion', {

				parent_id: parentId,
				
				type: 'city',

			}).then(function(res) {

				this.adress.city = res.body;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},
		// 获取县区
		getRegion(parentId, cityName) {

			this.Area.city = cityName;

			this.Area.region = "请选择";

			this.$http.post('/index/region/getregion', {

				parent_id: parentId,
				
				type: 'country',

			}).then(function(res) {

				this.adress.region = res.body;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},

		setArea(regionName) {

			this.Area.region = regionName;

			this.isDown = false;

		},
		
		getMyAdress() {

			this.$http.get('/indexs/users/getuseraddress').then(function(res) {

				this.myAdress = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		}, //三级联动结束
		//三级联动2

		UpDown2() {

			this.isDown2 = !this.isDown2;

		},

		getAdress2() {

			this.$http.post('/index/region/getregion', {

				parent_id: '0'

			}).then(function(res) {

				this.adress2.province = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},

		getCity2(parentId, provinceName) {

			this.Area2.city = "请选择";

			this.Area2.region = "请选择";

			this.Area2.province = provinceName;

			this.$http.post('/index/region/getregion', {

				parent_id: parentId

			}).then(function(res) {

				this.adress2.city = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},

		getRegion2(parentId, cityName) {

			this.Area2.city = cityName;

			this.Area2.region = "请选择";

			this.$http.post('/index/region/getregion', {

				parent_id: parentId

			}).then(function(res) {

				this.adress2.region = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},

		setArea2(regionName, regionId) {

			this.addareaId = regionId;

			this.Area2.region = regionName;

			this.isDown2 = false;

		},

		getMyAdress() {

			this.$http.get('/indexs/users/getuseraddress').then(function(res) {

				this.myAdress = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		}, //三级联动2结束
		//三级联动3

		UpDown3() {

			this.isDown3 = !this.isDown3;

		},

		getAdress3() {

			this.$http.post('/index/region/getregion', {

				parent_id: '0'

			}).then(function(res) {

				this.adress3.province = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},

		getCity3(parentId, provinceName) {

			this.Area3.city = "请选择";

			this.Area3.region = "请选择";

			this.Area3.province = provinceName;

			this.$http.post('/index/region/getregion', {

				parent_id: parentId

			}).then(function(res) {

				this.adress3.city = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},

		getRegion3(parentId, cityName) {

			this.Area3.city = cityName;

			this.Area3.region = "请选择";

			this.$http.post('/index/region/getregion', {

				parent_id: parentId

			}).then(function(res) {

				this.adress3.region = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},

		setArea3(regionName, regionId) {

			this.addareaId = regionId;

			this.Area3.region = regionName;

			this.isDown3 = false;

		},

		getMyAdress() {

			this.$http.get('/indexs/users/getuseraddress').then(function(res) {

				this.myAdress = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		}, //三级联动3结束
		//三级联动4

		UpDown4() {

			this.isDown4 = !this.isDown4;

		},

		getAdress4() {

			this.$http.post('/index/region/getregion', {

				parent_id: '0'

			}).then(function(res) {

				this.adress4.province = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},

		getCity4(parentId, provinceName) {

			this.Area4.city = "请选择";

			this.Area4.region = "请选择";

			this.Area4.province = provinceName;

			this.$http.post('/index/region/getregion', {

				parent_id: parentId

			}).then(function(res) {

				this.adress4.city = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},

		getRegion4(parentId, cityName) {

			this.Area4.city = cityName;

			this.Area4.region = "请选择";

			this.$http.post('/index/region/getregion', {

				parent_id: parentId

			}).then(function(res) {

				this.adress4.region = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		},

		setArea4(regionName, regionId) {

			this.addareaId = regionId;

			this.Area4.region = regionName;

			this.isDown4 = false;

		},

		getMyAdress() {

			this.$http.get('/indexs/users/getuseraddress').then(function(res) {

				this.myAdress = res.body.data;

			}, function(err) {

				console.log('请求失败处理' + err);

			});

		}, //三级联动4结束
		
		// 点击商品管理商品分类中的全选
		checkAll(){
			this.allCheck = !this.allCheck;
		},
		// 获取商城分类
		getCateList(){
			this.$http.get('/index/index/getSonCate').then(function(res) {
			
				this.cateList = res.body.data;
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
		},
		
		// 获取商品分类
		getGoodsCateList(){
			this.$http.get('/index/shops/getShopsCateList').then(function(res) {
			
				this.goodsCateList = res.body.data;
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
		},
		
		// 新增商品分类
		saveCate(pid,title){
			this.$http.post('/index/shops/editShopsCate', {
			
				pid: pid,
				title:title,
			
			}).then(function(res) {
				alert(res.body.msg)
				this.getGoodsCateList();
				// location.reload();
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
		},
		// 删除商品分类
		delCate(id){
			this.$http.post('/index/shops/delShopsCate', {
			
				id:id
			
			}).then(function(res) {
				alert(res.body.msg)
				this.getGoodsCateList();
				// location.reload();
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
		},
		// 修改商品分类
		changeCate(id,title){
			this.$http.post('/index/shops/editShopsCate', {
			
				id: id,
				title:title,
			
			}).then(function(res) {
				alert(res.body.msg)
				this.getGoodsCateList();
				// location.reload();
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
		},
		
		//点击商品管理--商品分类中的新增按钮

		addNewFenLei() {
			if($(".cloneLi").length>2){
				alert("请不要一次性添加多个分类")
			}
			$(".fenleiListBig").append($(".cloneLi").eq(0).clone());
			$(".cloneLi").eq(1).removeClass('hiddenLi');
			var that = this;
			$(".cloneLi").eq(1).find('.addShopsCate').click(function(){
				let title = $(".cloneInput").eq(1)[0].value;
				that.saveCate(0,title)
				$(".cloneLi").eq(1).remove();
			})
		},

		//点击商品管理--商品分类中的添加子分类

		addZiFenLei(e) {
			// console.log(this.$refs.pid)
			if($(".cloneZiLi").length > 2){
				alert("请不要一次性添加多个子分类")
			}
			e.currentTarget.parentElement.nextElementSibling.append($(".cloneZiLi").eq(0).clone()[0])
			$(".cloneZiLi").eq(1).removeClass('hiddenZiLi');
			var that = this;
			console.log(e.currentTarget.parentElement.nextElementSibling.children[0].value);
			var pid = e.currentTarget.parentElement.nextElementSibling.children[0].value;
			$('.addZiCate').eq(1).click(function(e){
				let title = $(".cloneZiInput").eq(1)[0].value;
				that.saveCate(pid,title)
				$(".cloneZiLi").eq(1).remove();
			})

		},

		//新增商品中的tab切换

		xinzenTab(i) {

			this.xinzenNum = i;

		},
		// 获取商品列表
		getGoodsList(){
			this.$http.get('/index/shops/getShopsGoodsList').then(function(res) {
			
				this.goodsList.data = res.body.data.data;
				this.goodsList.current_page = res.body.data.current_page;
				this.goodsList.last_page = res.body.data.last_page;
				this.goodsList.total = res.body.data.total;
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
		},
		// 点击取消清除商品数据
		clearGoods(){
			this.goods.title = '';
			this.goods.old_price = '';
			this.goods.new_price = '';
			this.goods.number_stock = '';
			this.goods.status = 1;
			this.goods.isShipping = 1;
			this.goods.cate_id = '';
			this.goods.cate_id = '';
			this.goods.content = 1;
			this.goods.images = '';
			this.goods.img = '';
			this.shopImages = [];
		},
		// 保存商品数据
		saveGoods(){
			this.$http.post('/index/shops/addShopsGoods', {
			
				cate_id:this.goods.cate_id,
				title:this.goods.title,
				old_price:this.goods.old_price,
				new_price:this.goods.new_price,
				number_stock:this.goods.number_stock,
				status:this.goods.status,
				is_shipping:this.goods.isShipping,
				shops_cate_id:this.goods.shops_cate_id,
				content:this.goods.content,
				brand_id:this.shopBrandId,
				image:this.goods.img,
				photos:this.goods.images,
			
			}).then(function(res) {
				alert(res.body.msg)
				this.getGoodsList();
				this.Sindex=3;
				// location.reload();
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
		},
		// 删除商品
		delGoods(id){
			this.$http.post('/index/shops/delShopsGoods',{
				id:id,
			}).then(function(res) {
				alert(res.body.msg)
				this.getGoodsList();
				// location.reload();
			
			}, function(err) {
			
				console.log('请求失败处理' + err);
			
			});
		},
		//配送管理--服务商设置--开通服务商

		kaitfuwush(i) {

			$(".kaitfuwush").eq(i).css("display", "none");
			$(".yikaitfuwush").eq(i).css("display", "block");

		},
		//配送管理--服务商设置--取消开通

		quxiaofuwush(i) {

			$(".kaitfuwush").eq(i).css("display", "inline-block");
			$(".yikaitfuwush").eq(i).css("display", "none");

		},

		//运费模板

		yunfeimubTab(i) {

			if (this.yunfeimubNum == i) {

				this.yunfeimubNum = -1;

			} else {

				this.yunfeimubNum = i;

			}

		},

		//配送管理中的我要寄快递tab切换

		jijianTab(i) {

			this.jijianNum = i

		},

		//点击已经寄件tab切换

		yijijianTab(i) {

			this.yijijianNum = i;

		},

		//投诉管理tab切换

		tousuguanliTab(i) {

			this.tousuguanliNum = i;

		},

		//投诉中心tab切换

		shengsuzhongxTab(i) {

			this.shengsuzhongxNum = i;

		},

		//结算中心tab切换

		jiesuanzhongxinTab(i) {

			this.jiesuanzhongxinNum = i;

		},

		//商铺装修tab

		shopPageTitTab(i) {

			this.shopPageTitNum = i;

		},





		//商铺装修页面tab

		shopPageTabBox() {

			this.shopPageNum = $(".shopZhuangXiuSelect option:selected").index();

			if (this.shopPageNum != 0) {

				$(".dianpuzhuangxiuCotBot").addClass("on");

			}

		},

		//关闭商铺装修按钮

		closeOption() {

			$(".dianpuzhuangxiuCotBot").removeClass("on");

		},

		//自定义页中的点击跳转

		tozdyChoice() {

			$(".zidingyiCot").eq(1).addClass("on").siblings().removeClass("on");

		},

		//自定义页面  取消

		zdyChoicequxiao() {

			alert("你点击了取消")

			$(".zidingyiCot").eq(0).addClass("on").siblings().removeClass("on");

		},

		//自定义页面  确定

		zdyChoicequeding() {

			alert("你点击了确定")

			$(".zidingyiCot").eq(0).addClass("on").siblings().removeClass("on");

		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},

	},

	mounted() {
		// 调用富文本编辑器
		var E = window.wangEditor;
		var editor = new E('#editor','#editorText');
		// 转base64位
		 editor.customConfig.uploadImgShowBase64 = true;
		 editor.customConfig.onchange = (html) => {
		   this.goods.content = html;
		 }
		// 调用图片上传
		// editor.customConfig.uploadImgServer = "/upload"; //上传图片的接口写在引号里
		editor.create();
		this.getAdress(); //三级联动
		this.getAdress2(); //三级联动2
		this.getAdress3(); //三级联动3
		this.getAdress4(); //三级联动4
		
		// 获取商铺资料
		this.getShopInfo();
		// 获取系统信息
		this.getSystemNews();
		// 获取商铺分类
		this.getGoodsCateList();
		// 获取商品列表
		this.getGoodsList();
		// 获取商城分类
		this.getCateList();
		// 获取品牌
		this.getShopBrand();

	},



})

//交易管理-已收货订单--导出点击事件

$(".yishhdaochu").click(function() {

	$(".yishouhuoddZhezhao").css("display", "block");

})

//导出--取消

$(".quxiaodaochu").click(function() {

	$(".yishouhuoddZhezhao").css("display", "none");

})
//导出--确定

$(".queddaochu").click(function() {

	$(".yishouhuoddZhezhao").css("display", "none");

	alert("已导出")

})
