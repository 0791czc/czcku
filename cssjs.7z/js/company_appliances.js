// 企业家电js
new Vue({
	el: '#qyjd',
	data: {
		// 数据
		data:{},
		// 导航数据
		jddaohang: [],
		// 轮播数据
		swiperData: [
			'/static/index/img/shopbanner.jpg',
			'/static/index/img/shopbanner.jpg',
			'/static/index/img/shopbanner.jpg',
			'/static/index/img/shopbanner.jpg',
			'/static/index/img/shopbanner.jpg',
			'/static/index/img/shopbanner.jpg',
		],
		// tab栏切换
		hotTab:0,
		// 爆款推荐
		hotsRecommend:[],
		// 商品数据
		goodslist:[],
		// 热销爆款导航
		rxdaohang: [],
		// 最新商品数据
		newGoodsList:[],
		// 日常推荐数据
		// brandList:[],
	},
	methods:{
		// 获取页面部分数据
		getData(){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getShop?id='+id).then(function(res) {
				this.data = res.body.data;
				this.jddaohang = res.body.data.nav;
				this.rxdaohang = this.jddaohang.slice(0,6);
				this.getGoodsData(this.rxdaohang[0].id);
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取爆款推荐
		getHotsRecommend(){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/banner/getBanners?id=21&shops_id='+id).then(function(res) {
				this.hotsRecommend = res.body.data;
				// this.swiperData.map(item => {
				// 	let image = new URLSearchParams
				// 	image.append("path", item.image)
				// 	image.append("interlace", true)
				// 	item.image = `/img_conv.php?${image.toString()}`
				// 	return item
				// })
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 热销tab栏切换
		rxtab(i){
			this.hotTab = i;
			this.getGoodsData(this.rxdaohang[i].id)
		},
		// 获取商品数据
		getGoodsData(shopcate){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getGoodsList?shopid='+id+'&shopcate='+shopcate).then(function(res) {
				this.goodslist = res.body.data.data;
				this.goodslist.map(item => {
					let image = new URLSearchParams
					image.append("path", item.logo)
					image.append("width", 210)
					image.append("height", 210)
					image.append("interlace", true)
					item.logo = `/img_conv.php?${image.toString()}`
					return item
				})
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取最新商品
		getNewGoodsData(){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getGoodsList?shopid='+id+'&num=9').then(function(res) {
				this.newGoodsList = res.body.data.data;
				this.newGoodsList.map(item => {
					let image = new URLSearchParams
					image.append("path", item.logo)
					image.append("width", 131)
					image.append("height", 179)
					image.append("interlace", true)
					item.logo = `/img_conv.php?${image.toString()}`
					return item
				})
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取优选品牌
		// getGoodsData(shopcate){
		// 	let id = this.$refs.companyId.value;
		// 	this.$http.get('/index/index/getShop?id='+id).then(function(res) {
		// 		this.goodslist = res.body.data;
		// 	},function(err) {
		// 		console.log('请求失败处理' + err);
		// 	});
		// },
		// 关注店铺
		collectShop(id){
			this.$http.post('/index/Users/usersCollect', {
				shops_id: id,
			}).then(function(res) {
				alert(res.body.msg)
				if(res.body.code==200){
					if(this.data.is_follow == 1){
						this.data.is_follow = 0;
					}else{
						this.data.is_follow = 1;
					}
				}
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},
	},
	mounted(){
		this.getData();
		this.getHotsRecommend();
		this.getNewGoodsData();
	},
})
