/**
 * @author Administrator
 */
//本周推荐js
//选择器
var jia = document.getElementsByClassName("jia")[0];
var jian = document.getElementsByClassName("jian")[0];
var yeshunum = document.getElementsByClassName("yeshunum")[0];
var yeshunumPars = parseInt(yeshunum.innerText);
var choiceK = document.getElementById("choiceK");
jia.onclick = function() {
	choiceKVal = choiceK.value;
	if(choiceKVal == yeshunum.innerHTML) {
		alert("这是最后一页，后面没有了哟")
	} else {
		choiceKVal++;
		choiceK.value = choiceKVal;
	}
}
jian.onclick = function() {
	choiceKVal = choiceK.value;
	if(choiceKVal == 1) {
		alert("这是第一页，前面没有了哟")
	} else {
		choiceKVal--;
		choiceK.value = choiceKVal;
	}
}
choiceK.onchange = function() {
	if(choiceK.value > yeshunumPars) {
		alert("最多只有" + yeshunumPars + "页");
		choiceK.value = yeshunumPars;
	} else if(choiceK.value < 1) {
		alert("不能小于一页");
		choiceK.value = 1;
	}
}

//调数据
var vm = new Vue({
	el: ".container",
	data: {
		headerH2:"",
		yeshu: 0,
		yema: 1,
		yeshu1: 0,
		yema1: 1,
		yeshu2: 0,
		yema2: 1,
		yeshu3: 0,
		yema3: 1,
		titTabNum: 0,
		electric: [],
		clothing: [],
		material: [],
		digital: [],
		brandData:[],
		brandData2:[],
		electricO: [],
		clothingO: [],
		materialO: [],
		digitalO: [],
	},
	methods: {
		yemajian() {
			if(this.yema <= 1) {
				this.yema = 1;
			} else {
				this.yema -= 1;
			}
		},
		yemajia() {
			if(this.yema >= this.yeshu) {
				this.yema = this.yeshu;
			} else {
				this.yema += 1;
			}
		},
		yemajian1() {
			if(this.yema1 <= 1) {
				this.yema1 = 1;
			} else {
				this.yema1 -= 1;
			}
		},
		yemajia1() {
			if(this.yema1 >= this.yeshu1) {
				this.yema1 = this.yeshu1;
			} else {
				this.yema1 += 1;
			}
		},
		yemajian2() {
			if(this.yema2 <= 1) {
				this.yema2 = 1;
			} else {
				this.yema2 -= 1;
			}
		},
		yemajia2() {
			if(this.yema2 >= this.yeshu2) {
				this.yema2 = this.yeshu2;
			} else {
				this.yema2 += 1;
			}
		},
		yemajian3() {
			if(this.yema3 <= 1) {
				this.yema3 = 1;
			} else {
				this.yema3 -= 1;
			}
		},
		yemajia3() {
			if(this.yema3 >= this.yeshu3) {
				this.yema3 = this.yeshu3;
			} else {
				this.yema3 += 1;
			}
		},
		titTab(i) {
			this.titTabNum = i;
		},
		// 获取品牌数据
		getBrandData(){
			this.$http.post('http://sert.zxits.cn/indexs/index/getband?cid='+334+"&&num="+17).then(function(res) {
				this.brandData = res.body;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取第二个品牌数据
		getBrandData2(){
			this.$http.post('http://sert.zxits.cn/indexs/index/getband?cid='+361+"&&num="+17).then(function(res) {
				this.brandData2 = res.body;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取海淘家用电器数据
		getElectric() {
			this.$http.get('/index/index/getSpecialGoods?special=6&&cate=1').then(function(res) {
				
				if (res.body.data.length > 8) {
				
					this.yeshu = Math.ceil(res.body.data.length / 8)
				
					for (var j = 0; j < this.yeshu; j++) {
				
						this.electric.push(res.body.data.splice(0, 8));
				
					}
				
				} else {
				
					this.electric.push(res.body.data);
				
				}
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取海淘服装服饰数据
		getClothing() {			this.$http.get('/index/index/getSpecialGoods?special=6&&cate=2').then(function(res) {
				
				if (res.body.data.length > 8) {
				
					this.yeshu1 = Math.ceil(res.body.data.length / 8)
				
					for (var j = 0; j < this.yeshu1; j++) {
				
						this.clothing.push(res.body.data.splice(0, 8));
				
					}
				
				} else {
				
					this.clothing.push(res.body.data);
				
				}
			},function(err) {
				console.log('请求失败处理' + err);
			});
			
		},		// 获取海淘家装建材数据
		getMaterial() {			this.$http.get('/index/index/getSpecialGoods?special=6&&cate=595').then(function(res) {
				
				if (res.body.data.length > 8) {
				
					this.yeshu2 = Math.ceil(res.body.data.length / 8)
				
					for (var j = 0; j < this.yeshu2; j++) {
				
						this.material.push(res.body.data.splice(0, 8));
				
					}
				
				} else {
				
					this.material.push(res.body.data);
				
				}
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},		// 获取海淘电子数码数据
		getDigital() {			this.$http.get('/index/index/getSpecialGoods?special=6&&cate=8').then(function(res) {
				
				if (res.body.data.length > 8) {
				
					this.yeshu3 = Math.ceil(res.body.data.length / 8)
				
					for (var j = 0; j < this.yeshu3; j++) {
				
						this.digital.push(res.body.data.splice(0, 8));
				
					}
				
				} else {
				
					this.digital.push(res.body.data);
				
				}
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		getElectricO() {
			this.$http.post('http://sert.zxits.cn/indexs/index/get_index_goods', {
				type: "maig",
				num: 4,
				catid: "334"
			}).then(function(res) {
				this.electricO = res.body;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		getClothingO() {
			this.$http.post('http://sert.zxits.cn/indexs/index/get_index_goods', {
				type: "maig",
				num: 4,
				catid: "348"
			}).then(function(res) {
				this.clothingO = res.body;
				//						console.log(this.clothing)
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		getMaterialO() {
			this.$http.post('http://sert.zxits.cn/indexs/index/get_index_goods', {
				type: "maig",
				num: 4,
				catid: "55"
			}).then(function(res) {
				this.materialO = res.body;
				//						console.log(res.body)
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		getDigitalO() {
			this.$http.post('http://sert.zxits.cn/indexs/index/get_index_goods', {
				type: "maig",
				num: 4,
				catid: "51"
			}).then(function(res) {
				this.digitalO = res.body;
				//						console.log(res.body)
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//页面跳转函数
		jumpNewhtml(url) {
			window.location.href = url;
		},
	},
	mounted() {
		this.getElectric(),
		// this.getBrandData(),
		// this.getBrandData2(),
			this.getClothing();
			this.getMaterial();
			this.getDigital();
			// this.getElectricO(),
			// this.getClothingO(),
			// this.getMaterialO(),
			// this.getDigitalO()
	}
})