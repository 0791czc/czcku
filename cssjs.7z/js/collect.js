var vm = new Vue({
	el: ".container",
	data: {
		checkNum: [],
		//					checkHUOwu:false,
		plshow: false,
		tabNum: 0,
		littleNum: 0,
		yeshu: 0,
		yema: 1,
		// 用户信息
		userInfo:{},
		// 收藏的商品，商铺，品牌
		goodslist: [],
		shopslist: [],
		brandlist: [],
	},
	methods: {
		theTab(i) {
			this.tabNum = i;
		},
		littleTab(i) {
			this.littleNum = i;
		},
		//分页
		yemajian() {
			if (this.yema <= 1) {
				this.yema = 1;
			} else {
				this.yema -= 1;
			}
		},
		yemajia() {
			if (this.yema >= this.yeshu) {
				this.yema = this.yeshu;
			} else {
				this.yema += 1;
			}
		},
		// 获取用户信息
		getUserInfo(){
			this.$http.get('/index/Users/getUserInfo').then(function(res) {
				this.userInfo = res.body.data;
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取收藏商品数据
		getCollectGoods() {
			this.$http.post('/index/Users/usersCollectList',{
				key: 'goods_id',
			}).then(function(res) {
				this.goodslist = res.body.data
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取收藏店铺数据
		getCollectShops() {
			this.$http.post('/index/Users/usersCollectList',{
				key: 'shops_id',
			}).then(function(res) {
				this.shopslist = res.body.data
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取收藏品牌数据
		getCollectBrands() {
			this.$http.post('/index/Users/usersCollectList',{
				key: 'brand_id',
			}).then(function(res) {
				this.brandlist = res.body.data
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//点击批量管理按钮
		pilianggli() {
			this.plshow = !this.plshow;
			if (this.plshow == true) {
				$('.huowutopImgHover').css("display", "none");
			} else {
				$('.huowutopImgHover').css("display", "block");
			}
		},
		//点击每一个选中删除
		imgdelhouwu(i, yeshu) {
			this.huowufenyemsg[yeshu][i].checkHUOwu = !this.huowufenyemsg[yeshu][i].checkHUOwu;
		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},
	},
	mounted() {
		this.getCollectGoods(); // 获取收藏商品数据
		this.getCollectShops(); // 获取收藏店铺数据
		this.getCollectBrands(); // 获取收藏品牌数据
		this.getUserInfo(); // 获取用户信息
	}
})
