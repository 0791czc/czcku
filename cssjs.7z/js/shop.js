new Vue({
    el:'#shouye',
    data : {
	  data:{},
	  // 是否为多品牌
	  brandsOn:false,
	  // 多品牌下的店铺分类导航
	  brandsNav:[],
      swiperData:[
        '/static/index/img/shopbanner.jpg',
        '/static/index/img/shopbanner.jpg',
        '/static/index/img/shopbanner.jpg',
        '/static/index/img/shopbanner.jpg',
        '/static/index/img/shopbanner.jpg',
      ],
	  // 存商品数据
	  goodslist:[],
    },
	methods:{
		// 获取页面部分数据
		getData(){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getShop?id='+id).then(function(res) {
				this.data = res.body.data;
				if (this.data instanceof Array) {
					this.data.map(item => {
						let image = new URLSearchParams
						image.append("path", item.logo)
						image.append("width", 210)
						image.append("height", 210)
						image.append("interlace", true)
						item.logo = `/img_conv.php?${image.toString()}`
						return item
					})
				}
				for (let i in this.data.nav) {
					this.getGoodsData(this.data.nav[i].id)
				}
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取商品数据
		getGoodsData(shopcate){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getGoodsList?shopid='+id+'&shopcate='+shopcate+'&num=4').then(function(res) {
				this.goodslist.push(res.body.data.data);
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 关注店铺
		collectShop(id){
			this.$http.post('/index/Users/usersCollect', {
				shops_id: id,
			}).then(function(res) {
				alert(res.body.msg)
				if(res.body.code==200){
					if(this.data.is_follow == 1){
						this.data.is_follow = 0;
					}else{
						this.data.is_follow = 1;
					}
				}
			}, function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},
	},
	mounted() {
		this.getData();
	}
})