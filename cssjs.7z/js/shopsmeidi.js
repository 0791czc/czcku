new Vue({
	el:".bigBox",
	data:{
		tabNum:0,
		msg:[
			{
				list:[
					"/xlshop/indexs/view/img/mdimg1.png"
				]
			},
			{
				list:[
				"/xlshop/indexs/view/img/mdimg2.png","/xlshop/indexs/view/img/mdimg3.png"
				]
	
			},
			{
				list:[
					"/xlshop/indexs/view/img/mdimg4.png"
				]
			},
			{
				list:[
				"/xlshop/indexs/view/img/mdimg5.png","/xlshop/indexs/view/img/mdimg6.png"
				]
			},
			{
				list:[
					"/xlshop/indexs/view/img/mdimg7.png"
				]
			},
			{
				list:[
				"/xlshop/indexs/view/img/mdimg8.png","/xlshop/indexs/view/img/mdimg9.png"
				]
			}
		]
	},
	methods:{
		tab(i){
			this.tabNum=i;
			console.log(this.msg)
		}
	}
})
//返回顶部
    var btn = document.getElementById('btn');
    var scrollTop ;
    var timer = null;
    window.onscroll = function(){
        scrollTop = document.documentElement.scrollTop||document.body.scrollTop;//兼容性写法，并且在滚动事件内可以实时获得滚动条距顶部的距离
        return scrollTop;
    }
    btn.onclick = function(){
        clearInterval(timer);
        timer = setInterval(function(){
            var now = scrollTop;
            var speed = (0-now)/10;
            speed = speed>0?Math.ceil(speed):Math.floor(speed);//这三步设置是定时器里面可以使速度动态变化，达到有缓冲的效果，如果房子定时器外面的话，返回顶部的速度是匀速的。

            if(scrollTop==0){
                clearInterval(timer);
            }
                document.documentElement.scrollTop =  scrollTop + speed;
                document.body.scrollTop =  scrollTop + speed;

        },30)

    }