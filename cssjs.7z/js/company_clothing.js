new Vue({
    el:'#qydz',
    data:{
		// 页面部分数据
		data:{},
    	//头部导航
        jddaohang:[],
        //轮播
        swiperData:[
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
            '/static/index/img/shopbanner.jpg',
          ],
        //本周新品数据
         bzxinpin: [],
        //热门推荐内容
        rmneirong:[],
		// 热门推荐tab栏
		tabNum:0,
    },
	methods:{
		// 获取页面部分数据
		getData(){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getShop?id='+id).then(function(res) {
				this.data = res.body.data;
				this.jddaohang = res.body.data.nav;
				for (let i in this.jddaohang) {
					this.getGoodsData(this.jddaohang[i].id)
				}
				this.getRmneirong(this.jddaohang[0].id)
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取商品数据
		getGoodsData(shopcate){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getGoodsList?shopid='+id+'&shopcate='+shopcate+'&num=3').then(function(res) {
				this.bzxinpin.push(res.body.data.data);
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		// 获取第二页商品数据
		getRmneirong(shopcate){
			let id = this.$refs.companyId.value;
			this.$http.get('/index/index/getGoodsList?shopid='+id+'&shopcate='+shopcate+'&page=2&num=3').then(function(res) {
				this.rmneirong = res.body.data.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		hotTab(i){
			this.tabNum = i;
			this.getRmneirong(this.jddaohang[i].id);
		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},
	},
	mounted() {
		this.getData();
	}
})