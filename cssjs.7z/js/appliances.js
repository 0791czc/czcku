new Vue({
    el: '#appliances',
    data: {
        // 冰箱导航数据
        nanzhuang:[],
        // 空调导航数据
        nvzhuang:[],
        // 电视导航数据
        neiyi:[],
        // 洗衣机导航数据
        peishi:[],
        // 厨卫电器导航数据
        tongzhuang:[],
        // 小家电导航数据
        small:[],
        // 家居电器导航数据
        jiajudianqi:[],
        // 生活小家电导航数据
        lifejiadian:[],
        // banner图上方导航
        headNav:[],
        // 轮播数据
        swiperData:[],
        swiperData2:[],
        swiperOption1: {
			slidesPerView: 1,
			spaceBetween: 30,
			loop: true,
			observer: true,
			observeParents: true,
			lazy: {
				loadPrevNext: true,
			},
			autoplay: {
				delay: 3000,
				disableOnInteraction: false,
			},
			pagination: {
				el: '.swiper-pagination',
				clickable: true,
			},
			navigation: {
				nextEl: '.swiper-button-next',
				prevEl: '.swiper-button-prev',
			}
		},
		swiperOption2: {
			slidesPerView: 2,
			spaceBetween: 0,
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption3: {
			slidesPerView: 1,
			spaceBetween: 0,
			direction: 'vertical',
			loop: true,
			observer: true,
			observeParents: true,
			autoplay: {
				delay: 4000,
				disableOnInteraction: false,
			}
		},
		swiperOption4: {
			slidesPerView: 5,
			observer: true,
			observeParents: true,
			loop: true,
			on: {
				click: function (e) {
					console.log(e.target.dataset.jumpurl)
					console.log(e.currentTarget)
					console.log(this.realIndex)
					// const id = this.realIndex;
					// vm.viewDetails(id);
				}
			},
			autoplay: {
				delay: 5000,
				disableOnInteraction: false,
			},
        },
        // 全部商品导航
        cebian:[],
        // 冰箱列表
        bingxiang:[],
        // 空调列表
        kongtiao:[],
        // 电视
        dianshi:[],
        // 洗衣机
        xiyiji:[],
        // 厨卫电器
        chuweidianqilist:[],
        // 小家电
        smalllist:[],
        // 家居电器
        jiajudianqilist:[],
        // 生活小家电
        lifejiadianlist:[],

    },
    methods: {
		// 获取导航数据
		getlist() {
			this.$http.get('/index/index/getIndexGoodsCate?cate=1').then(function (res) {
				if (res.body.code == 200) {
					this.nanzhuang = res.body.data[0].children;
					this.nvzhuang = res.body.data[1].children;
					this.neiyi = res.body.data[2].children;
                    this.peishi = res.body.data[3].children;
                    this.tongzhuang = res.body.data[4].children;
                    this.small = res.body.data[5].children;
                    this.jiajudianqi = res.body.data[6].children;
                    this.lifejiadian = res.body.data[7].children;
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/type/getList?pid=1').then(function (res) {
				if (res.body.code == 200) {
					this.headNav = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
			this.$http.get('/index/index/getIndexGoodsCate').then(function (res) {
				if (res.body.code == 200) {
					this.cebian = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/banner/getBanners?id=14').then(function (res) {
				if (res.body.code == 200) {
					this.swiperData = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/banner/getBanners?id=11').then(function (res) {
				if (res.body.code == 200) {
					this.swiperData2 = res.body.data
					
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
        },
        // 获取各个品牌店数据
        getgoodslist(){
			this.$http.get('/index/index/getGoodsList?cate=702&num=6').then(function (res) {
				if (res.body.code == 200) {
                    console.log(res.body.data)
                    this.bingxiang = res.body.data.data
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=704&num=6').then(function (res) {
				if (res.body.code == 200) {
                    console.log(res.body.data)
                    this.dianshi = res.body.data.data
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=703&num=6').then(function (res) {
				if (res.body.code == 200) {
                    console.log(res.body.data)
                    this.kongtiao = res.body.data.data
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=705&num=6').then(function (res) {
				if (res.body.code == 200) {
                    console.log(res.body.data)
                    this.xiyiji = res.body.data.data
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=708&num=6').then(function (res) {
				if (res.body.code == 200) {
                    console.log(res.body.data)
                    this.jiajudianqilist = res.body.data.data
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=709&num=6').then(function (res) {
				if (res.body.code == 200) {
                    console.log(res.body.data)
                    this.lifejiadianlist = res.body.data.data
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=707&num=6').then(function (res) {
				if (res.body.code == 200) {
                    console.log(res.body.data)
                    this.smalllist = res.body.data.data
				}
			}, function (err) {
				console.log('请求失败处理' + err);
            });
            this.$http.get('/index/index/getGoodsList?cate=706&num=6').then(function (res) {
				if (res.body.code == 200) {
                    console.log(res.body.data)
                    this.chuweidianqilist = res.body.data.data
				}
			}, function (err) {
				console.log('请求失败处理' + err);
			});
        }
    },
    created () {
        this.getlist()
        this.getgoodslist()
    }
})