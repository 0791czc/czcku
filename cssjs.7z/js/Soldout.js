/**
 * @author Administrator
 */
//卖光为止js
//调数据
var vm = new Vue({
	el: "#container",
	data: {
		headerH2: "",
		titTabNum: 0,
		electric: [],
		clothing: [],
		material: [],
		digital: [],

	},
	methods: {
		titTab(i) {
			this.titTabNum = i;
		},
		//获取卖光为止家用电器栏目数据
		getElectric(){
			this.$http.get('/index/index/getSpecialGoods?special=3&&cate=1').then(function(res) {
				console.log(res);
				this.electric = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取卖光为止服装服饰栏目数据
		getClothing() {
			this.$http.get('/index/index/getSpecialGoods?special=3&&cate=2').then(function(res) {
				console.log(res);
				this.clothing = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取卖光为止家装建材栏目数据
		getMaterial() {
			this.$http.get('/index/index/getSpecialGoods?special=3&&cate=595').then(function(res) {
				console.log(res);
				this.material = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//获取卖光为止电子数码栏目数据
		getDigital() {
			this.$http.get('/index/index/getSpecialGoods?special=3&&cate=8').then(function(res) {
				console.log(res);
				this.digital = res.body.data;
			},function(err) {
				console.log('请求失败处理' + err);
			});
		},
		//页面跳转函数
		jumpNewhtml(url){
			window.location.href = url;
		},
	},
	mounted() {
		this.getElectric(),
			this.getClothing(),
			this.getMaterial(),
			this.getDigital()
	}
})